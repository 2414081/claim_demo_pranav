from typing import Dict
from langchain_core.runnables import Runnable
from langchain_core.messages import HumanMessage
from langchain_community.chat_models import AzureChatOpenAI
import json


def supervisor_agent() -> Runnable:
    """
    Supervisor agent that determines the next step in the claim processing workflow based on the document verification result.
    """

    def run_agent(state: Dict):
        # Extract document verification result from state
        doc_result = state.get("document_check_result", {})
        doc_status = doc_result.get("status", "failed") if doc_result else "failed"
        claim_id = (
            doc_result.get("claim_id", f"CLM_{state.get('policy_id', 'unknown')}")
            if doc_result
            else f"CLM_{state.get('policy_id', 'unknown')}"
        )

        # Convert state to JSON string for LLM input
        state_str = json.dumps(state, indent=2)

        # Initialize LLM
        llm = AzureChatOpenAI(
            openai_api_key="6ffhCm6wvgxD2LRD7wNZI5sHgqHn4lqYOY7xn8Ycdg7vHvZ8qyujJQQJ99BCACYeBjFXJ3w3AAABACOGwuFA",
            openai_api_version="2023-07-01-preview",
            azure_deployment="gpt-4o",
            azure_endpoint="https://tcoeaiteamgpt4o.openai.azure.com/",
        )

        # Define the prompt
        messages = [
            HumanMessage(
                content=f"""You are an AI supervisor agent tasked with determining the next step in an insurance claim processing workflow based on the current state. You will receive:
                1. The current state of the claim processing graph, including the document verification result.
                
                Your task is to:
                - Review the document verification result (status: 'passed' or 'failed') in the state.
                - If the document verification status is 'passed', set the next step to 'END' (indicating the workflow can conclude).
                - If the document verification status is 'failed', set the next step to 'END' and provide a reason for termination.
                - Assign a confidence score (between 0.0 and 1.0) based on the clarity of the decision:
                    - Use 0.9 if the document verification status is explicitly 'passed' or 'failed'.
                    - Use 0.5 if the document verification result is missing or unclear.
                - Output STRICTLY a JSON result with the following fields:
                    - `timestamp`: Use "2025-06-26T16:45:00".
                    - `claim_id`: Use the claim_id from the document verification result or state.
                    - `step`: The agent name, "supervisor_agent".
                    - `next_step_node`: The next node in the workflow ('END' in this case).
                    - `reason`: A concise explanation of the decision.
                    - `confidence`: A float between 0.0 and 1.0 reflecting confidence in the decision.

                **Input Data:**

                Current State:
                {state_str}

                **Instructions:**
                1. Check the `document_check_result` in the state for the document verification status.
                2. Determine the next step based on the document verification status:
                    - If 'passed', set `next_step_node` to 'END'.
                    - If 'failed', set `next_step_node` to 'END' with a reason.
                3. Output the result in the following JSON format, with no additional text:

                {{
                    "timestamp": "2025-06-26T16:45:00",
                    "claim_id": "{claim_id}",
                    "step": "supervisor_agent",
                    "next_step_node": "END",
                    "reason": "explanation",
                    "confidence": 0.0
                }}
                """
            )
        ]

        # Get LLM response
        response = llm.invoke(messages)
        response_content = (
            response.content.strip().replace("```json", "").replace("```", "")
        )
        result = json.loads(response_content)

        # Update state with supervisor result
        return {
            "supervisor_result": result,
            "next_step_node": result["next_step_node"],
            "reason": result["reason"],
            "input": state,
        }

    return run_agent
