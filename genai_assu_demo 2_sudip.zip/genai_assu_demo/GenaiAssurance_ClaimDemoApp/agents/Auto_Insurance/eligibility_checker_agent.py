# agents/eligibility_checker_agent.py

from langchain_core.runnables import Runnable
from langchain_core.messages import HumanMessage
from langchain_openai import AzureChatOpenAI
import os
from dotenv import load_dotenv
from configuration.logger import log_trace
import json
from langchain_core.runnables import Runnable
from langchain_core.runnables import RunnableLambda
from supervisor.supervisor_agent import *
from configuration.state import GraphState
from typing import Dict, Any
from datetime import datetime

# Define the Eligibility Agent
# def get_eligibility_agent() -> Runnable:
#     def run_agent(input: dict):
#         claim_id = input.get("claim_id", "")
#         claim_details = input.get("claim_details", "")
#
#         messages = [
#             HumanMessage(
#                 content=f""" Evaluate the eligibility of the following insurance claim:
#                         {claim_details}
#                         Analyze the claim details and determine if they are Eligible or Not Eligible
#                         Output should be strictly in the following JSON format:
#                         {{
#                         "Eligibility": "Eligible"
#                         "Confidence Score(0 to 1)": "0.9"
#                         }}
#                         If the information is missing or unclear, do your best to conclude based on what's available. Do not ask follow-up questions.
#                         """
#             )
#         ]
#         response = llm.invoke(messages)
#         result = response.content
#         log_trace(claim_id, "eligibility_checker_agent", {"output": result})
#         return {**input, "Eligibility_check_result": result}
#
#     return run_agent


def eligibility_checker_agent(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        state_data = state.dict()
        claim_record = state_data.get("claim_record", {})
        rules = state_data.get("rules", [])
        policy_id = claim_record.get("policy_id", "UNKNOWN")
        claim_id = f"{policy_id}"

        rules = [
            {
                "policy_active_status": "The policy must be active with all premiums paid up to date at the time of the incident."
            },
            {
                "coverage_compliance": "The damages claimed must fall under collision coverage as outlined in the policy terms."
            },
            {
                "incident_date_verification": "The incident must occur within the covered policy period."
            },
            {
                "driver_eligibility": "The driver involved in the incident must be authorized and covered by the policy."
            },
        ]

        prompt = f"""
        You are an AI assistant tasked with validating an insurance claim for the eligibility_checker_agent based on provided claim details and predefined rules. You will receive:
1. A claim record with fields: `name`, `policy_id`, `policy_start`, `policy_end`, `claim_type`, `accident_date`, `claim_amount`, and `notes` (a list of strings indicating rule validations or inferences).
2. Provided Rules for the eligibility_checker_agent for the claim type 'Auto Insurance (Collision Coverage)'.

Your task is to:
- Validate the claim record against the provided rules for the eligibility_checker_agent.
- Check the `notes` for explicit rule validations (e.g., "eligibility_checker_agent: description").
- For rules not explicitly mentioned in `notes`, infer compliance based on the claim fields (e.g., check `accident_date` against `policy_start` and `policy_end` for `incident_date_verification`).
- If any rule fails, the agent's status is "failed". All rules must pass for the status to be "passed".
- Assign a confidence score (between 0.0 and 1.0) based on the strength of the evidence or inference:
  - Use 0.9 for rules explicitly validated in notes.
  - Use 0.6–0.8 for inferred validations based on fields.
  - Use 0.4–0.5 for rules requiring external data with no explicit note.
- Output STRICTLY a JSON result with a single entry for the eligibility_checker_agent, including:
  - `timestamp`: Use "2025-06-26T16:45:00".
  - `claim_id`: Constructed as `CLM_{policy_id}`.
  - `step`: The agent name, "eligibility_checker_agent".
  - `status`: Either "passed" or "failed".
  - `reason`: A concise explanation of the validation result.
  - `confidence`: A float between 0.0 and 1.0 reflecting confidence in the result.

**Input Data:**

Claim Record:  
{json.dumps(claim_record, indent=2)}

Rules for eligibility_checker_agent (Claim Type 'Auto Insurance (Collision Coverage)'):  
{json.dumps(rules, indent=2)}

**Instructions:**
1. For the eligibility_checker_agent:
   - Check the `notes` for explicit rule validations.
   - For rules not in `notes`, infer compliance based on fields. For example:
     - For `incident_date_verification`, check if `accident_date` falls between `policy_start` and `policy_end`.
     - For `policy_active_status`, assume premiums are paid unless contradicted.
     - For rules requiring external data (e.g., `incident_veracity`), use notes or assume partial compliance with lower confidence if no note exists.
   - If any rule fails, the status is "failed". All rules must pass for "passed".
2. Output the result in the following JSON format, with no additional text:

{
  {
    "timestamp": "2025-06-26T16:45:00",
    "claim_id": "{policy_id}",
    "step": "eligibility_checker_agent",
    "status": "<passed/failed>",
    "reason": "<explanation>",
    "confidence": 0.0
  }
}

        """
        response = llm.invoke([HumanMessage(content=prompt)])

        try:
            response_content = (
                response.content.strip().replace("```json", "").replace("```", "")
            )
            parsed = json.loads(response_content)
            print(f"Parsed LLM response: {parsed}")  # Debugging line
            # if (
            #     not isinstance(parsed, list)
            #     or not parsed
            #     or not isinstance(parsed[0], dict)
            # ):
            #     raise ValueError(
            #         "Invalid LLM output: Expected a list with a dictionary"
            #     )
        except (json.JSONDecodeError, ValueError) as e:
            parsed = [
                {
                    "timestamp": datetime.utcnow().isoformat(),
                    "claim_id": claim_id,
                    "step": "eligibility_checker_agent",
                    "status": "failed",
                    "reason": f"Unable to parse LLM output: {str(e)}",
                    "confidence_score": 0.0,
                }
            ]
        #parsed[0]["raw_llm_response"] = response.content
        log_trace(claim_id=claim_id, step="eligibility_checker_agent", output=parsed)
        return {"eligibility_check_result": parsed, "input": state_data}

    return RunnableLambda(run)
