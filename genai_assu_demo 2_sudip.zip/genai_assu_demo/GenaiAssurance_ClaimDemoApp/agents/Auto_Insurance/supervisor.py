from langgraph.graph import END
from typing import Dict, Any
from configuration.state import GraphState
from configuration.logger import log_trace


def supervisor_agent(state: GraphState) -> Dict[str, Any]:
    log_trace(state.policy_id, "supervisor_agent_input", {"state": state.dict()})
    doc_status = (
        state.document_check_result.get("document_check_status")
        if state.document_check_result
        else None
    )
    eligibility_status = (
        state.eligibility_check_result.get("eligibility_status")
        if state.eligibility_check_result
        else None
    )
    fraud_score = state.fraud_score  # Get the latest fraud score
    human_review_required = (
        state.human_review_required
    )  # Get the latest human review flag
    summary = bool(state.summary)
    decision = bool(state.decision)

    # New flags to track completed fraud checks
    damage_consistency_checked = state.damage_consistency_checked
    repair_estimate_checked = state.repair_estimate_checked
    duplicate_claim_checked = state.duplicate_claim_checked
    incident_veracity_checked = state.incident_veracity_checked

    print(
        f"\n--- SupervisorAgent ---\nState: doc_status={doc_status}, "
        f"eligibility_status={eligibility_status}, fraud_score={fraud_score}, "
        f"human_review_required={human_review_required}, summary={summary}, "
        f"decision={decision}"
        f"\nFraud Checks: Damage={damage_consistency_checked}, Repair={repair_estimate_checked}, "
        f"Duplicate={duplicate_claim_checked}, Veracity={incident_veracity_checked}"
    )

    # Handle initial document rejection
    if doc_status == "rejected" and not summary:
        print("❌ Document rejected. Routing to SummaryAgent.")
        return {"next_step_node": "SummaryAgent"}
    elif doc_status == "rejected" and summary and not decision:
        print("❌ Document rejected, summary available. Routing to DecisionMaker.")
        return {"next_step_node": "DecisionMaker"}
    # Document approved, proceed to EligibilityChecker if not done
    elif doc_status == "approved" and eligibility_status is None:
        print("✅ Document approved. Routing to EligibilityChecker.")
        return {"next_step_node": "EligibilityChecker"}
    elif eligibility_status == "rejected":
        if not summary:
            print("❌ Eligibility rejected. Routing to SummaryAgent.")
            return {"next_step_node": "SummaryAgent"}
        elif summary and not decision:  # Assuming decision_present is a state variable
            print(
                "❌ Eligibility rejected, summary available. Routing to DecisionMaker."
            )
            return {"next_step_node": "DecisionMaker"}

    # Eligibility approved, start fraud checks
    elif eligibility_status == "approved":
        # Check if any fraud score is present and requires summary
        if fraud_score is not None and fraud_score > 0 and not summary:
            print(f"⚠️ Fraud score {fraud_score} detected. Routing to SummaryAgent.")
            return {"next_step_node": "SummaryAgent"}
        elif fraud_score is not None and fraud_score > 0 and summary and not decision:
            print(
                f"⚠️ Fraud score {fraud_score} detected, summary available. Routing to DecisionMaker."
            )
            return {"next_step_node": "DecisionMaker"}

        # If no significant fraud score yet, proceed through fraud sub-agents
        if not damage_consistency_checked:
            print("➡️ Routing to FraudDamageConsistency.")
            return {
                "next_step_node": "FraudDamageConsistency",
                "damage_consistency_checked": True,
            }
        elif not repair_estimate_checked:
            print("➡️ Routing to FraudRepairEstimate.")
            return {
                "next_step_node": "FraudRepairEstimate",
                "repair_estimate_checked": True,
            }
        elif not duplicate_claim_checked:
            print("➡️ Routing to FraudDuplicateClaim.")
            return {
                "next_step_node": "FraudDuplicateClaim",
                "duplicate_claim_checked": True,
            }
        elif not incident_veracity_checked:
            print("➡️ Routing to FraudIncidentVeracity.")
            return {
                "next_step_node": "FraudIncidentVeracity",
                "incident_veracity_checked": True,
            }
        # All fraud checks completed with no significant score, and no summary yet
        elif not summary:
            print(
                "✅ All fraud checks completed without significant fraud. Routing to SummaryAgent."
            )
            return {"next_step_node": "SummaryAgent"}
        # All checks completed, summary available, and no decision yet
        elif summary and not decision:
            print("✅ Summary available. Proceeding to DecisionMaker.")
            return {"next_step_node": "DecisionMaker"}
    # Fallback/Completion
    print("✅ All checks completed or invalid state. Ending workflow.")
    return {"next_step_node": END}
