from evaluations1.prompts import *
from langchain_core.messages import HumanMessage
from datetime import datetime
import json
from typing import Dict

AGENT_METADATA = {
    # ------------------------------
    # Medical Domain Tools
    # ------------------------------
    "provider_verification_result": {
        "tool_name": "verify_provider_npi",
        "tool_description": "Verifies whether a healthcare provider is registered in the National Provider Identifier (NPI) registry.",
    },
    "prior_medical_claims_result": {
        "tool_name": "lookup_prior_claims",
        "tool_description": "Checks whether the same medical procedure has been previously claimed under the same policy to detect duplicates.",
    },
    "coverage_rules_check_result": {
        "tool_name": "check_coverage_rules",
        "tool_description": "Validates whether a specific procedure is covered under a given medical policy.",
    },
    "medical_cost_benchmark_result": {
        "tool_name": "benchmark_medical_cost",
        "tool_description": "Compares the claimed medical procedure cost against standardized benchmark rates.",
    },
    # ------------------------------
    # Vehicle Domain Tools
    # ------------------------------
    "vehicle_vin_verification_result": {
        "tool_name": "verify_vehicle_vin",
        "tool_description": "Verifies whether the provided vehicle VIN is valid and exists in the registry.",
    },
    "prior_vehicle_claims_result": {
        "tool_name": "lookup_previous_vehicle_claims",
        "tool_description": "Detects if a previous claim was already filed for the same vehicle and accident date.",
    },
    "repair_cost_check_result": {
        "tool_name": "check_repair_cost_estimate",
        "tool_description": "Checks if the repair cost for a specific vehicle damage type is within acceptable benchmark ranges.",
    },
    "police_report_url_validation_result": {
        "tool_name": "validate_police_report_url",
        "tool_description": "Validates whether the police report URL is accessible and returns a successful response.",
    },
}


def generate_tool_eval_prompt(result_key: str, inputs: Dict, output: Dict) -> str:
    metadata = AGENT_METADATA.get(result_key)
    if not metadata:
        return ""  # skip

    return TOOL_CALL_EVAL_TEMPLATE.format(
        tool_name=metadata["tool_name"],
        tool_description=metadata["tool_description"],
        tool_inputs=json.dumps(inputs, indent=2),
        tool_output=json.dumps(output, indent=2),
    )


def evaluate_all_tool_outputs(
    results: Dict[str, Dict], state_inputs: Dict[str, Dict], llm
) -> Dict[str, Dict]:
    """
    Loops through all tool outputs in the results dict and evaluates using the tool prompts.
    """
    evaluations = {}
    for result_key, output in results.items():
        prompt = generate_tool_eval_prompt(
            result_key, state_inputs.get(result_key, {}), output
        )
        if not prompt:
            continue
        try:
            response = llm.invoke([HumanMessage(content=prompt)])
            parsed = json.loads(response.content)
            parsed["timestamp"] = datetime.utcnow().isoformat()
            evaluations[result_key] = parsed
        except Exception as e:
            evaluations[result_key] = {
                "score": 0.0,
                "justification": f"Error evaluating tool {result_key}: {str(e)}",
                "tool_call_correct": False,
                "timestamp": datetime.utcnow().isoformat(),
            }
    return evaluations
