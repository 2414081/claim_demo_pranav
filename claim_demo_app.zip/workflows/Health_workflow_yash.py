from langgraph.graph import StateGraph, END
from typing import Optional, Literal, Dict, Any
from pydantic import BaseModel
from langchain_core.runnables import Runnable, RunnableLambda
from configuration.llm_manager import LLMManager
from configuration.logger import log_trace
from agents.Health_Insurance.document_verifier_agent import document_verifier_agent
from agents.Health_Insurance.eligibility_checker_agent import eligibility_checker_agent

# Import individual fraud sub-agents for Health Insurance
from agents.Health_Insurance.fraud_checker_agent import (  # Assuming this is your new file for health sub-agents
    fraud_duplicate_claim_checker,
    fraud_inconsistency_checker,
    fraud_provider_verification_checker,
    fraud_service_reasonability_checker,
)

from agents.Health_Insurance.summarizer_agent import get_summarizer_agent
from agents.Health_Insurance.decision_agent import decision_maker_agent
from agents.Health_Insurance.supervisor_agent import (
    supervisor_agent_medical,
)  # Renamed to avoid clash, as requested
from configuration.state import GraphState


class ClaimAgents:
    def __init__(self, llm):
        self.llm = llm

    def document_verifier_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "document_verifier_agent_input",
                {"state": state.dict()},
            )
            output = document_verifier_agent(self.llm).invoke(state)
            result = output.get("document_verification_result", [{}])[0]
            # Print statements added for clearer tracing, similar to auto insurance example
            print(f"Document Verifier Output: {result}")
            status = (
                "rejected" if result.get("status", "failed") != "passed" else "approved"
            )
            log_trace(state.policy_id, "document_verifier_agent", result)
            print(f"Document Verifier Status: {status}")
            return {
                "doc_status": status,
                "claim_id": result.get("claim_id", f"CLM_{state.policy_id}"),
                "raw_llm_response": result.get("raw_llm_response"),
            }

        return RunnableLambda(run)

    def eligibility_checker_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "eligibility_checker_agent_input",
                {"state": state.dict()},
            )
            output = eligibility_checker_agent(self.llm).invoke(state)
            result = output.get("eligibility_check_result", [{}])
            # Print statements added for clearer tracing, similar to auto insurance example
            print(f"Eligibility Checker Output: {result}")
            status = (
                "rejected" if result.get("status", "failed") != "passed" else "approved"
            )
            log_trace(state.policy_id, "eligibility_checker_agent", result)
            return {
                "eligibility_status": status,
                "claim_id": result.get("claim_id", f"CLM_{state.policy_id}"),
                "raw_llm_response": result.get("raw_llm_response"),
            }

        return RunnableLambda(run)

    # Individual Health Insurance Fraud Sub-agents
    def fraud_duplicate_claim_agent_health(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "fraud_duplicate_claim_agent_health_input",
                {"state": state.dict()},
            )
            output = fraud_duplicate_claim_checker(self.llm).invoke(state)
            log_trace(state.policy_id, "fraud_duplicate_claim_agent_health", output)
            # Ensure the state is updated with the correct flags for supervisor
            return {
                "duplicate_claim_check_result": output.get(
                    "duplicate_claim_check_result"
                ),
                "fraud_score": output.get("fraud_score"),
                "human_review_required": output.get("human_review_required"),
                "duplicate_claim_checked": True,  # Mark this check as complete
            }

        return RunnableLambda(run)

    def fraud_inconsistency_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "fraud_inconsistency_agent_input",
                {"state": state.dict()},
            )
            output = fraud_inconsistency_checker(self.llm).invoke(state)
            log_trace(state.policy_id, "fraud_inconsistency_agent", output)
            return {
                "inconsistency_check_result": output.get("inconsistency_check_result"),
                "fraud_score": output.get("fraud_score"),
                "human_review_required": output.get("human_review_required"),
                "inconsistency_checked": True,  # Mark this check as complete
            }

        return RunnableLambda(run)

    def fraud_provider_verification_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "fraud_provider_verification_agent_input",
                {"state": state.dict()},
            )
            output = fraud_provider_verification_checker(self.llm).invoke(state)
            log_trace(state.policy_id, "fraud_provider_verification_agent", output)
            return {
                "provider_verification_check_result": output.get(
                    "provider_verification_check_result"
                ),
                "fraud_score": output.get("fraud_score"),
                "human_review_required": output.get("human_review_required"),
                "provider_verification_checked": True,  # Mark this check as complete
            }

        return RunnableLambda(run)

    def fraud_service_reasonability_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "fraud_service_reasonability_agent_input",
                {"state": state.dict()},
            )
            output = fraud_service_reasonability_checker(self.llm).invoke(state)
            log_trace(state.policy_id, "fraud_service_reasonability_agent", output)
            return {
                "service_reasonability_check_result": output.get(
                    "service_reasonability_check_result"
                ),
                "fraud_score": output.get("fraud_score"),
                "human_review_required": output.get("human_review_required"),
                "service_reasonability_checked": True,  # Mark this check as complete
            }

        return RunnableLambda(run)

    def summary_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(state.policy_id, "summary_agent_input", {"state": state.dict()})
            output = get_summarizer_agent(self.llm).invoke(state)
            log_trace(state.policy_id, "summary_agent", output)
            return {
                "summary": output.get("summary"),
                "summary_confidence": output.get("confidence_score", 0.0),
            }

        return RunnableLambda(run)

    def decision_maker_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id, "decision_maker_agent_input", {"state": state.dict()}
            )
            output = decision_maker_agent(state)
            log_trace(
                state.claim_id or f"CLM_{state.policy_id}",
                "decision_maker_agent",
                output,
            )
            return output

        return RunnableLambda(run)

    def supervisor_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            if not isinstance(state, GraphState):
                log_trace(
                    "UNKNOWN",
                    "supervisor_agent_error",
                    {"error": "Invalid state type", "state": str(state)},
                )
                raise ValueError("Supervisor agent received invalid state type")
            log_trace(
                state.policy_id, "supervisor_agent_input", {"state": state.dict()}
            )
            # IMPORTANT: Using supervisor_agent_medical as per your request for Health Insurance
            output = supervisor_agent_medical(state)
            log_trace(state.policy_id, "supervisor_agent", output)
            return output

        return RunnableLambda(run)


def create_graph_Health_Insurance():
    llm_manager = LLMManager()
    azure_openai = llm_manager.get_llm()
    agent = ClaimAgents(azure_openai)

    builder = StateGraph(GraphState)

    builder.add_node("DocumentVerifier", agent.document_verifier_agent())
    builder.add_node("EligibilityChecker", agent.eligibility_checker_agent())

    # Add individual Health Insurance fraud sub-agents as nodes
    builder.add_node(
        "FraudDuplicateClaimChecker", agent.fraud_duplicate_claim_agent_health()
    )
    builder.add_node("FraudInconsistencyChecker", agent.fraud_inconsistency_agent())
    builder.add_node(
        "FraudProviderVerificationChecker", agent.fraud_provider_verification_agent()
    )
    builder.add_node(
        "FraudServiceReasonabilityChecker", agent.fraud_service_reasonability_agent()
    )

    builder.add_node("SummaryAgent", agent.summary_agent())
    builder.add_node("DecisionMaker", agent.decision_maker_agent())
    builder.add_node("Supervisor", agent.supervisor_agent())

    builder.set_entry_point("DocumentVerifier")

    # Define edges to the Supervisor
    builder.add_edge("DocumentVerifier", "Supervisor")
    builder.add_edge("EligibilityChecker", "Supervisor")

    # Health fraud sub-agents transition to Supervisor
    builder.add_edge("FraudDuplicateClaimChecker", "Supervisor")
    builder.add_edge("FraudInconsistencyChecker", "Supervisor")
    builder.add_edge("FraudProviderVerificationChecker", "Supervisor")
    builder.add_edge("FraudServiceReasonabilityChecker", "Supervisor")

    builder.add_edge("SummaryAgent", "Supervisor")
    builder.add_edge("DecisionMaker", END)

    # Define conditional edges from the Supervisor
    builder.add_conditional_edges(
        "Supervisor",
        lambda state: state.next_step_node,
        {
            "EligibilityChecker": "EligibilityChecker",
            # Conditional edges for each Health Insurance fraud sub-agent
            "FraudDuplicateClaimChecker": "FraudDuplicateClaimChecker",
            "FraudInconsistencyChecker": "FraudInconsistencyChecker",
            "FraudProviderVerificationChecker": "FraudProviderVerificationChecker",
            "FraudServiceReasonabilityChecker": "FraudServiceReasonabilityChecker",
            "SummaryAgent": "SummaryAgent",
            "DecisionMaker": "DecisionMaker",
            END: END,
        },
    )

    return builder.compile()
