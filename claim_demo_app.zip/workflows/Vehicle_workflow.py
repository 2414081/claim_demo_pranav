from langgraph.graph import StateGraph, END
from typing import Optional, Literal, Dict, Any
from pydantic import BaseModel
from langchain_core.runnables import Runnable
from langchain_core.runnables import RunnableLambda
from configuration.llm_manager import LLMManager
from configuration.logger import log_trace
from agents.Auto_Insurance.document_verifier_agent import document_verifier_agent
from agents.Auto_Insurance.eligibility_checker_agent import eligibility_checker_agent

# Import individual fraud sub-agents
from agents.Auto_Insurance.fraud_checker_agent import (
    fraud_damage_consistency_checker,
    fraud_repair_estimate_checker,
    fraud_duplicate_claim_checker,
    fraud_incident_veracity_checker,
)
from agents.Auto_Insurance.sumarizer_agent import get_summarizer_agent
from agents.Auto_Insurance.decision_agent import decision_maker_agent
from agents.Auto_Insurance.supervisor import supervisor_agent
from configuration.state import GraphState


class ClaimAgents:
    def __init__(self, llm):
        self.llm = llm

    def document_verifier_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "document_verifier_agent_input",
                {"state": state.dict()},
            )
            output = document_verifier_agent(self.llm).invoke(state)
            result = output.get("document_verification_result", [{}])[0]
            print(f"Document Verifier Output: {result}")
            raw_status = result.get("doc_status", "failed")
            status = "rejected" if raw_status != "passed" else "approved"
            log_trace(
                state.policy_id,
                "document_verifier_agent",
                {
                    "raw_output": result,
                    "mapped_status": status,
                    "claim_id": result.get("claim_id"),
                    "reason": result.get("reason"),
                    "confidence_score": result.get("confidence_score"),
                },
            )
            print(f"Document Verifier Status: {status}")
            document_output = {
                "document_check_status": status,
                "document_check_reason": result.get("reason", ""),
            }
            return {
                # "doc_status": status,
                # "claim_id": result.get("claim_id", f"CLM_{state.policy_id}"),
                # "raw_llm_response": result.get("raw_llm_response"),
                "document_check_result": document_output
            }

        return RunnableLambda(run)

    def eligibility_checker_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "eligibility_checker_agent_input",
                {"state": state.dict()},
            )
            output = eligibility_checker_agent(self.llm).invoke(state)
            result = output.get("eligibility_check_result", [{}])[0]
            print(f"Eligibility Checker Output: {result}")
            raw_status = result.get("status", "failed")
            status = "rejected" if raw_status != "passed" else "approved"
            log_trace(
                state.policy_id,
                "eligibility_checker_agent",
                {
                    "raw_output": result,
                    "mapped_status": status,
                    "claim_id": result.get("claim_id"),
                    "reason": result.get("reason"),
                    "confidence_score": result.get("confidence_score"),
                },
            )
            eligibility_output = {
                "eligibility_status": status,
                "eligibility_reason": result.get("reason", ""),
            }
            return {
                # "eligibility_status": status,
                # "claim_id": result.get("claim_id", f"CLM_{state.policy_id}"),
                # "raw_llm_response": result.get("raw_llm_response"),
                "eligibility_check_result": eligibility_output
            }

        return RunnableLambda(run)

    # Individual Fraud Sub-agents
    def fraud_damage_consistency_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "fraud_damage_consistency_agent_input",
                {"state": state.dict()},
            )
            output = fraud_damage_consistency_checker(self.llm).invoke(state)
            log_trace(state.policy_id, "fraud_damage_consistency_agent", output)
            return {
                "damage_consistency_check_result": output.get(
                    "damage_consistency_check_result"
                ),
                "fraud_score": output.get("fraud_score"),
                "human_review_required": output.get("human_review_required"),
            }

        return RunnableLambda(run)

    def fraud_repair_estimate_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "fraud_repair_estimate_agent_input",
                {"state": state.dict()},
            )
            output = fraud_repair_estimate_checker(self.llm).invoke(state)
            log_trace(state.policy_id, "fraud_repair_estimate_agent", output)
            return {
                "repair_estimate_check_result": output.get(
                    "repair_estimate_check_result"
                ),
                "fraud_score": output.get("fraud_score"),
                "human_review_required": output.get("human_review_required"),
            }

        return RunnableLambda(run)

    def fraud_duplicate_claim_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "fraud_duplicate_claim_agent_input",
                {"state": state.dict()},
            )
            output = fraud_duplicate_claim_checker(self.llm).invoke(state)
            log_trace(state.policy_id, "fraud_duplicate_claim_agent", output)
            return {
                "duplicate_claim_check_result": output.get(
                    "duplicate_claim_check_result"
                ),
                "fraud_score": output.get("fraud_score"),
                "human_review_required": output.get("human_review_required"),
            }

        return RunnableLambda(run)

    def fraud_incident_veracity_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id,
                "fraud_incident_veracity_agent_input",
                {"state": state.dict()},
            )
            output = fraud_incident_veracity_checker(self.llm).invoke(state)
            log_trace(state.policy_id, "fraud_incident_veracity_agent", output)
            return {
                "incident_veracity_check_result": output.get(
                    "incident_veracity_check_result"
                ),
                "fraud_score": output.get("fraud_score"),
                "human_review_required": output.get("human_review_required"),
            }

        return RunnableLambda(run)

    def summary_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(state.policy_id, "summary_agent_input", {"state": state.dict()})
            output = get_summarizer_agent(self.llm).invoke(state)
            log_trace(state.policy_id, "summary_agent", output)
            return {
                "summary": output.get("summary"),
                "summary_confidence": output.get("confidence_score", 0.0),
            }

        return RunnableLambda(run)

    def decision_maker_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            log_trace(
                state.policy_id, "decision_maker_agent_input", {"state": state.dict()}
            )
            output = decision_maker_agent(state)
            log_trace(
                state.claim_id or f"CLM_{state.policy_id}",
                "decision_maker_agent",
                output,
            )
            return output

        return RunnableLambda(run)

    def supervisor_agent(self) -> Runnable:
        def run(state: GraphState) -> Dict[str, Any]:
            if not isinstance(state, GraphState):
                log_trace(
                    "UNKNOWN",
                    "supervisor_agent_error",
                    {"error": "Invalid state type", "state": str(state)},
                )
                raise ValueError("Supervisor agent received invalid state type")
            log_trace(
                state.policy_id, "supervisor_agent_input", {"state": state.dict()}
            )
            output = supervisor_agent(state)
            log_trace(state.policy_id, "supervisor_agent", output)
            return output

        return RunnableLambda(run)


# def create_graph_Auto_Insurance():
#     llm_manager = LLMManager()
#     azure_openai = llm_manager.get_llm()
#     agent = ClaimAgents(azure_openai)

#     builder = StateGraph(GraphState)
#     builder.add_node("DocumentVerifier", agent.document_verifier_agent())
#     builder.add_node("EligibilityChecker", agent.eligibility_checker_agent())
#     builder.add_node("FraudChecker", agent.fraud_checker_agent())
#     builder.add_node("SummaryAgent", agent.summary_agent())
#     builder.add_node("DecisionMaker", agent.decision_maker_agent())
#     builder.add_node("Supervisor", agent.supervisor_agent())

#     builder.set_entry_point("DocumentVerifier")
#     builder.add_edge("DocumentVerifier", "Supervisor")
#     builder.add_edge("EligibilityChecker", "Supervisor")
#     builder.add_edge("FraudChecker", "Supervisor")
#     builder.add_edge("SummaryAgent", "Supervisor")
#     builder.add_edge("DecisionMaker", END)

#     builder.add_conditional_edges(
#         "Supervisor",
#         lambda state: state.next_step_node,
#         {
#             "EligibilityChecker": "EligibilityChecker",
#             "FraudChecker": "FraudChecker",
#             "SummaryAgent": "SummaryAgent",
#             "DecisionMaker": "DecisionMaker",
#             END: END,
#         },
#     )

#     return builder.compile()


def create_graph_Auto_Insurance():

    llm_manager = LLMManager()
    azure_openai = llm_manager.get_llm()
    agent = ClaimAgents(azure_openai)

    builder = StateGraph(GraphState)
    builder.add_node("DocumentVerifier", agent.document_verifier_agent())
    builder.add_node("EligibilityChecker", agent.eligibility_checker_agent())
    # Add individual fraud sub-agents as nodes
    builder.add_node("FraudDamageConsistency", agent.fraud_damage_consistency_agent())
    builder.add_node("FraudRepairEstimate", agent.fraud_repair_estimate_agent())
    builder.add_node("FraudDuplicateClaim", agent.fraud_duplicate_claim_agent())
    builder.add_node("FraudIncidentVeracity", agent.fraud_incident_veracity_agent())
    builder.add_node("SummaryAgent", agent.summary_agent())
    builder.add_node("DecisionMaker", agent.decision_maker_agent())
    builder.add_node(
        "Supervisor", agent.supervisor_agent()
    )  # The supervisor will now handle transitions between fraud agents and to summary/end

    builder.set_entry_point("DocumentVerifier")
    builder.add_edge("DocumentVerifier", "Supervisor")
    builder.add_edge(
        "EligibilityChecker", "Supervisor"
    )  # EligibilityChecker now transitions to Supervisor

    # Fraud sub-agents transition to Supervisor
    builder.add_edge("FraudDamageConsistency", "Supervisor")
    builder.add_edge("FraudRepairEstimate", "Supervisor")
    builder.add_edge("FraudDuplicateClaim", "Supervisor")
    builder.add_edge("FraudIncidentVeracity", "Supervisor")

    builder.add_edge("SummaryAgent", "Supervisor")
    builder.add_edge("DecisionMaker", END)

    builder.add_conditional_edges(
        "Supervisor",
        lambda state: state.next_step_node,
        {
            "EligibilityChecker": "EligibilityChecker",
            "FraudDamageConsistency": "FraudDamageConsistency",
            "FraudRepairEstimate": "FraudRepairEstimate",
            "FraudDuplicateClaim": "FraudDuplicateClaim",
            "FraudIncidentVeracity": "FraudIncidentVeracity",
            "SummaryAgent": "SummaryAgent",
            "DecisionMaker": "DecisionMaker",
            END: END,
        },
    )

    return builder.compile()
