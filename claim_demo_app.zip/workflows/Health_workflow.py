from langgraph.graph import StateGraph, END
from typing import Dict, Optional, TypedDict
from langchain.chat_models import AzureChatOpenAI

from agents.Health.document_agent import health_document_agent
from agents.Health.decision_agent import decision_agent


class ClaimRecord(TypedDict):
    name: str
    policy_id: str
    policy_start: str
    policy_end: str
    claim_type: str
    accident_date: str
    claim_amount: float
    notes: list[str]


class GraphState(TypedDict):
    policy_id: str
    domain: str
    claim_record: ClaimRecord
    document_check_result: Optional[Dict]
    decision_result: Optional[Dict]
    decision: Optional[str]
    reason: Optional[str]


class LLMManager:
    def create_azure_openai_llm(self):
        return AzureChatOpenAI(
            openai_api_key="6ffhCm6wvgxD2LRD7wNZI5sHgqHn4lqYOY7xn8Ycdg7vHvZ8qyujJQQJ99BCACYeBjFXJ3w3AAABACOGwuFA",
            openai_api_version="2023-07-01-preview",
            azure_deployment="gpt-4o",
            azure_endpoint="https://tcoeaiteamgpt4o.openai.azure.com/",
        )


class ClaimAgents:
    def __init__(self, llm):
        self.llm = llm

    def document_verifier_agent(self, state: GraphState) -> Dict:
        # Invoke the health_document_agent with the state
        return health_document_agent()(state)

    def decision_agent(self, state: GraphState) -> Dict:
        return decision_agent()(state)


def create_health_graph(state):
    """
    Constructs and compiles the LangGraph StateGraph for insurance claim processing.
    """
    # Instantiate LLM and agent manager
    llm_manager = LLMManager()
    azure_openai = llm_manager.create_azure_openai_llm()
    agent = ClaimAgents(azure_openai)

    # Create graph builder with your state class
    builder = StateGraph(GraphState)

    # Add agent nodes
    builder.add_node("DocumentVerifier", agent.document_verifier_agent)
    builder.add_node("DecisionMaker", agent.decision_agent)

    # Set entry point
    builder.set_entry_point("DocumentVerifier")

    # Define edges
    builder.add_edge("DocumentVerifier", "DecisionMaker")
    builder.add_edge("DecisionMaker", END)

    # Compile and return the graph
    return builder.compile()
