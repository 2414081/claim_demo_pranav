# evaluation/prompts.py

TOOL_SELECTION_EVAL_TEMPLATE = """
You are an evaluator assessing whether an AI agent selected the correct tool (agent) for a given step in an insurance claim workflow.

Claim Type: {claim_type}
Current Step Input:
{step_input}

Tool Invoked: {tool_invoked}
Available Tools: {available_tools}
Agent's Thought: {agent_thought}

Was the tool selection appropriate for this step? Consider whether the data matches the tool's responsibility (e.g., document_verifier_agent handles document and policy checks).

Respond in JSON:
{{
  "score": <0.0 to 1.0>,
  "justification": "<explanation>",
  "tool_correct": <true/false>
}}
"""

TOOL_CALL_EVAL_TEMPLATE = """
You are evaluating the correctness of a tool (agent) call in an insurance claim processing system.

Tool Name: {tool_name}
Expected Purpose: {tool_description}
Inputs Provided:
{tool_inputs}

Output Produced:
{tool_output}

Does the tool have all necessary inputs to perform its task? Was the output consistent with those inputs and the tool's role?

Respond in JSON:
{{
  "score": <0.0 to 1.0>,
  "input_completeness": "<brief comment>",
  "output_validity": "<brief comment>",
  "tool_call_correct": <true/false>
}}
"""

DECISION_EVAL_TEMPLATE = """
You are reviewing the final decision made by an insurance claim AI system.

Claim Type: {claim_type}
Final Decision Output:
{decision_output}

Summary of Claim:
- Document Status: {doc_status}
- Eligibility Status: {eligibility_status}
- Fraud Status: {fraud_status}
- Fraud Score: {fraud_score}

Evaluate whether the decision logic was correct based on prior agent results. If any earlier step failed, rejection may be justified. If all passed and fraud risk is low, approval is expected.

Respond in JSON:
{{
  "score": <0.0 to 1.0>,
  "decision_correct": <true/false>,
  "justification": "<explanation>"
}}
"""

REFLECTION_EVAL_TEMPLATE = """
You are evaluating whether an AI agent’s reasoning or reflection was logical and accurate for a specific claim processing step.

Agent Name: {agent_name}
Reflection Output:
{reflection}

Was the reasoning sound, based on claim data, notes, rules, and the agent's responsibilities?

Respond in JSON:
{{
  "score": <0.0 to 1.0>,
  "reasoning_valid": <true/false>,
  "justification": "<explanation>"
}}
"""
FINAL_CALL_EVAL_TEMPLATE = """
You are an evaluator reviewing the full execution of an insurance claim workflow handled by an AI system. Your goal is to assess whether the end-to-end workflow — from document verification to decision — was logically sound.

Claim Type: {claim_type}
Claim ID: {claim_id}

Full Workflow Summary:
- Document Verification Status: {doc_status}
- Eligibility Status: {eligibility_status}
- Fraud Status: {fraud_status}
- Fraud Score: {fraud_score}
- Summary Text: {summary}
- Final Decision: {decision}
- Decision Reason: {decision_reason}
- Confidence Score: {decision_confidence}

Trace Data:
{trace_log}

Evaluate the following:
1. Were all agents invoked in the correct order?
2. Did each agent's result logically lead to the next?
3. Was the final decision aligned with the claim data and intermediate results?

Respond in the following JSON format:
{{
  "score": <0.0 to 1.0>,
  "final_decision_correct": <true/false>,
  "workflow_integrity": "<brief note on agent sequencing>",
  "decision_alignment": "<brief justification>",
  "recommendation": "<pass/reject/manual_review>"
}}
"""
