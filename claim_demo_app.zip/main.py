import os, re
import sys
from dotenv import load_dotenv
import pandas as pd
from openinference.instrumentation.openai import OpenAIInstrumentor
from arize.otel import register
from openinference.instrumentation.langchain import LangChainInstrumentor
from pathlib import Path
from collections import defaultdict
from arize.otel import register

from workflows.Health_workflow_yash import (
    create_graph_Health_Insurance,
)

# from workflows.travel_workflow import create_travel_workflow

from workflows.Vehicle_workflow import create_graph_Auto_Insurance
from workflows.Vehicle_workflow import GraphState
from supervisor.supervisor_agent import ClaimClassifierAgent

from evaluations.log_offline_evaluation import evaluate_using_llm

load_dotenv()

SPACE_ID = os.getenv("ARIZE_SPACE_ID")
API_KEY = os.getenv("ARIZE_API_KEY")
# AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
# AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")

# os.environ["AZURE_OPENAI_API_KEY"] = AZURE_OPENAI_API_KEY
# os.environ["AZURE_OPENAI_ENDPOINT"] = AZURE_OPENAI_ENDPOINT


# Setup OTEL via our convenience function
tracer_provider = register(
    space_id=SPACE_ID,  # in app space settings page
    api_key=API_KEY,  # in app space settings page
    project_name="tracing-Claim_insurance_demo",  # name this to whatever you would like
)

# Finish automatic instrumentation
OpenAIInstrumentor().instrument(tracer_provider=tracer_provider)


#
# def transform_row_to_claim_input(row: dict) -> dict:
#     return {
#         "policy_id": row["policy_id"],
#         "domain": row["domain"],  # e.g., "vehicle", "health", etc.
#         "document_text": row.get("document", ""),
#         "claim_record": {
#             "name": row.get("name"),
#             "policy_id": row.get("policy_id"),
#             "policy_start": row.get("policy_start"),
#             "policy_end": row.get("policy_end"),
#             "claim_type": row.get("domain"),  # or use a more specific mapping if needed
#             "accident_date": row.get("accident_date"),
#             "claim_amount": row.get("claim_amount"),
#             "notes": [],  # optional: fill from other data or prior steps
#         },
#         "rules": [],  # optional: fill with rules if needed
#         # Workflow-specific status placeholders
#         "doc_status": None,
#         "eligibility_status": None,
#         "fraud_score": None,
#         "fraud_status": None,
#         "summary": None,
#         "decision": None,
#         "reason": None,
#         "next_step_node": None,
#     }
#
#
# workflow_map = {
#     "Auto_Insurance": create_graph_Auto_Insurance(),
#     # "health": create_health_workflow,
#     # "travel": create_travel_workflow
# }
#
#
# df = pd.read_csv("notebooks/df_claims.csv", encoding="ISO-8859-1")
#
#
# for _, row in df.iterrows():
#     input_data = transform_row_to_claim_input(row)
#     domain = input_data.get("domain")
#
#     if domain not in workflow_map:
#         print(f"❌ Unsupported claim type: {domain}")
#         continue
#
#     print(f"\n🚀 Running workflow for claim {input_data['policy_id']} ({domain})...")
#     workflow = workflow_map[domain]
#     result = workflow.invoke(input_data)
#     result.pop("next_step_node", None)
#     print("✅ Final Result:", result)


def extract_estimated_cost(document: str) -> str:
    """Extract estimated cost from document text using regex."""
    match = re.search(r"Estimated repair cost:.*?₹?([\d,]+)", document, re.IGNORECASE)
    return match.group(1).replace(",", "") if match else "unknown"


def transform_row_to_claim_input(row: pd.Series) -> dict:
    document = str(row.get("document", ""))
    estimated_cost = extract_estimated_cost(document)
    is_valid_claim = bool(row.get("is_valid_claim", False))
    reason = str(row.get("reason", ""))
    policy_id = str(row.get("policy_id", "UNKNOWN"))
    domain = str(row.get("domain", "Auto_Insurance"))
    rules = [f"document_verification: {reason}"] if is_valid_claim and reason else []

    input_data = {
        "policy_id": policy_id,
        "domain": domain,
        "document_text": document,
        "estimated_damage_cost": estimated_cost,
        "is_valid_claim": is_valid_claim,
        "reason": reason,
        "claim_record": {
            "name": str(row.get("name", "")),
            "policy_id": policy_id,
            "policy_start": str(row.get("policy_start", "")),
            "policy_end": str(row.get("policy_end", "")),
            "claim_type": domain,
            "accident_date": str(row.get("accident_date", "")),
            "claim_amount": float(row.get("claim_amount", 0)),
            "notes": row.get("notes", []),
        },
        "rules": rules,
        "doc_status": None,
        "eligibility_status": None,
        "fraud_score": None,
        "fraud_status": None,
        "summary": None,
        "decision": None,
        "next_step_node": None,
    }

    # Convert row to dict for JSON serialization
    row_dict = row.to_dict() if isinstance(row, pd.Series) else row
    # log_trace(
    #     policy_id,
    #     "transform_row_to_claim_input",
    #     {"row": row_dict, "input_data": input_data},
    # )
    return input_data


workflow_map = {
    "Auto_Insurance": create_graph_Auto_Insurance(),
}

if __name__ == "__main__":
    # df = pd.read_csv("notebooks/df_claims.csv", encoding="ISO-8859-1")
    # print("Excel Data:", df.to_dict(orient="records"))
    input_data = {
        "policy_id": "POL_987_MANUAL_PASS",
        "domain": "Auto_Insurance",
        "document_text": """
            Vehicle Registration: Valid.
            Driver's License: Valid, issued 5 years ago.
            Police Report: Incident occurred on 6/26/2025 at 10:30 AM, involving minor collision.
            Photos: 4 high-resolution images showing consistent front-bumper damage.
            Repair Estimate: Official estimate from 'Certified Auto Repair' for 2800 USD. Estimated repair cost: ₹2800.
            All documents appear authentic and complete.
        """,
        "estimated_damage_cost": "2800.00 USD",  # Explicitly set this for repair estimate agent
        "is_valid_claim": True,
        "reason": "All primary documents are valid, complete, and consistent. Claim record is well-formed.",
        "claim_record": {
            "name": "Robert Johnson",
            "policy_id": "POL_987_MANUAL_PASS",
            "policy_start": "01/01/2025",
            "policy_end": "12/31/2025",  # Use string format for dates
            "claim_type": "Auto Insurance (Collision Coverage or Theft)",
            "accident_date": "06/26/2025",
            "claim_amount": 2800.00,
            "notes": [
                "document_verification_agent - required_documents_check: Passed. All documents submitted and verified as authentic.",
                "document_verification_agent - incident_date_verification: Passed. Accident date falls within policy period",
                "eligibility_checker_agent - policy_active_at_incident: Passed. Policy was active.",
                "eligibility_checker_agent - coverage_matches_claim_type: Passed. Collision coverage applies to this claim type.",
                "fraud_checker_agent - damage_consistency: Passed. Damages in photos are fully consistent with police report and claim description. No discrepancies.",
                "fraud_checker_agent - repair_estimate_inconsistencies: Passed. Repair estimate of 2800 USD is highly consistent with observed minor damage and typical repair costs. No overestimation.",
                "fraud_checker_agent - duplicate_claim_prevention: Passed. No previous claims found for this policyholder or vehicle. Unique incident.",
                "fraud_checker_agent - incident_veracity: Passed. Police report, driver's statement, and witness accounts are perfectly aligned. Incident details are highly credible with no suspicious elements.",
            ],
        },
        "rules": [
            "document_verification: All necessary documents are provided and appear valid.",
            "eligibility: Policy is active and covers the reported incident type.",
            "fraud_check: No indicators of fraud detected across all checks.",
        ],
        "doc_status": None,  # Will be updated by the workflow
        "eligibility_status": None,  # Will be updated by the workflow
        "fraud_score": None,  # Will be updated by the workflow
        "fraud_status": None,  # Will be updated by the workflow
        "summary": None,  # Will be updated by the workflow
        "decision": None,  # Will be updated by the workflow
        "next_step_node": None,  # Will be updated by the workflow
        "human_review_required": None,  # Added as per new state
        "damage_consistency_check_result": None,  # To be filled by agent
        "repair_estimate_check_result": None,  # To be filled by agent
        "duplicate_claim_check_result": None,  # To be filled by agent
        "incident_veracity_check_result": None,  # To be filled by agent
        "damage_consistency_checked": False,  # To be set by supervisor
        "repair_estimate_checked": False,  # To be set by supervisor
        "duplicate_claim_checked": False,  # To be set by supervisor
        "incident_veracity_checked": False,  # To be set by supervisor
        "raw_llm_response": None,  # To be filled by agents
    }
    domain = input_data.get("domain")
    workflow = workflow_map[domain]  # Debug Excel input
    result = workflow.invoke(input_data)
    result.pop("next_step_node", None)
    print("✅ Final Result:", result)
    # for _, row in df.iterrows():
    #     input_data = transform_row_to_claim_input(row)
    #     domain = input_data.get("domain")

    #     if domain not in workflow_map:
    #         print(f"❌ Unsupported claim type: {domain}")
    #         continue

    #     print(
    #         f"\n🚀 Running workflow for claim {input_data['policy_id']} ({domain})..."
    #     )
    #     workflow = workflow_map[domain]
    #     result = workflow.invoke(input_data, config={"recursion_limit": 50})
    #     result.pop("next_step_node", None)
    #     print("✅ Final Result:", result)

    # ----------------------------------------------------------


# import os
# import sys
# from dotenv import load_dotenv
# from openinference.instrumentation.openai import OpenAIInstrumentor
# from arize.otel import register
# from openinference.instrumentation.langchain import LangChainInstrumentor


# from workflows.Health_workflow_yash import (
#     create_graph_Health_Insurance,
# )  # , create_health_workflow

# # from workflows.travel_workflow import create_travel_workflow
# import os
# from dotenv import load_dotenv
# import re
# import pandas as pd
# from workflows.Vehicle_workflow import create_graph_Auto_Insurance
# from openinference.instrumentation.openai import OpenAIInstrumentor
# from workflows.Vehicle_workflow import GraphState
# from supervisor.supervisor_agent import ClaimClassifierAgent

# # Load environment variables from .env filevenv
# load_dotenv()

# # Retrieve credentials from environment variables
# SPACE_ID = os.getenv("ARIZE_SPACE_ID")
# API_KEY = os.getenv("ARIZE_API_KEY")
# AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
# AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")

# os.environ["AZURE_OPENAI_API_KEY"] = AZURE_OPENAI_API_KEY
# os.environ["AZURE_OPENAI_ENDPOINT"] = AZURE_OPENAI_ENDPOINT

# # Import open-telemetry dependencies
# from arize.otel import register

# # Import open-telemetry dependencies
# from arize.otel import register

# # Setup OTEL via our convenience function
# tracer_provider = register(
#     space_id=SPACE_ID,  # in app space settings page
#     api_key=API_KEY,  # in app space settings page
#     project_name="tracing-Claim_insurance_demo",  # name this to whatever you would like
# )
# # Import the automatic instrumentor from OpenInference
# from openinference.instrumentation.openai import OpenAIInstrumentor

# # Finish automatic instrumentation
# OpenAIInstrumentor().instrument(tracer_provider=tracer_provider)


# #
# # def transform_row_to_claim_input(row: dict) -> dict:
# #     return {
# #         "policy_id": row["policy_id"],
# #         "domain": row["domain"],  # e.g., "vehicle", "health", etc.
# #         "document_text": row.get("document", ""),
# #         "claim_record": {
# #             "name": row.get("name"),
# #             "policy_id": row.get("policy_id"),
# #             "policy_start": row.get("policy_start"),
# #             "policy_end": row.get("policy_end"),
# #             "claim_type": row.get("domain"),  # or use a more specific mapping if needed
# #             "accident_date": row.get("accident_date"),
# #             "claim_amount": row.get("claim_amount"),
# #             "notes": [],  # optional: fill from other data or prior steps
# #         },
# #         "rules": [],  # optional: fill with rules if needed
# #         # Workflow-specific status placeholders
# #         "doc_status": None,
# #         "eligibility_status": None,
# #         "fraud_score": None,
# #         "fraud_status": None,
# #         "summary": None,
# #         "decision": None,
# #         "reason": None,
# #         "next_step_node": None,
# #     }
# #
# #
# # workflow_map = {
# #     "Auto_Insurance": create_graph_Auto_Insurance(),
# #     # "health": create_health_workflow,
# #     # "travel": create_travel_workflow
# # }
# #
# #
# # df = pd.read_csv("notebooks/df_claims.csv", encoding="ISO-8859-1")
# #
# #
# # for _, row in df.iterrows():
# #     input_data = transform_row_to_claim_input(row)
# #     domain = input_data.get("domain")
# #
# #     if domain not in workflow_map:
# #         print(f"❌ Unsupported claim type: {domain}")
# #         continue
# #
# #     print(f"\n🚀 Running workflow for claim {input_data['policy_id']} ({domain})...")
# #     workflow = workflow_map[domain]
# #     result = workflow.invoke(input_data)
# #     result.pop("next_step_node", None)
# #     print("✅ Final Result:", result)


# def extract_estimated_cost(document: str) -> str:
#     """Extract estimated cost from document text using regex."""
#     match = re.search(r"Estimated repair cost:.*?₹?([\d,]+)", document, re.IGNORECASE)
#     return match.group(1).replace(",", "") if match else "unknown"


# def transform_row_to_claim_input(row: pd.Series) -> dict:
#     document = str(row.get("document", ""))
#     estimated_cost = extract_estimated_cost(document)
#     is_valid_claim = bool(row.get("is_valid_claim", False))
#     reason = str(row.get("reason", ""))
#     policy_id = str(row.get("policy_id", "UNKNOWN"))
#     domain = str(row.get("claim_type", "Auto_Insurance"))
#     rules = [f"document_verification: {reason}"] if is_valid_claim and reason else []


#     input_data = {
#         "policy_id": policy_id,
#         "domain": domain,
#         "document_text": document,
#         "estimated_damage_cost": estimated_cost,
#         "is_valid_claim": is_valid_claim,
#         "reason": reason,
#         "claim_record": {
#             "name": str(row.get("name", "")),
#             "policy_id": policy_id,
#             "policy_start": str(row.get("policy_start", "")),
#             "policy_end": str(row.get("policy_end", "")),
#             "claim_type": domain,
#             "accident_date": str(row.get("accident_date", "")),
#             "claim_amount": float(row.get("claim_amount", 0)),
#             "notes": row.get("notes", []),
#         },
#         "rules": rules,
#         "doc_status": None,
#         "eligibility_status": None,
#         "fraud_score": None,
#         "fraud_status": None,
#         "summary": None,
#         "decision": None,
#         "next_step_node": None,
#         "human_review_required": None, # Added as per new state
#         # Health-specific fraud check results and flags
#         "duplicate_claim_check_result": None, # To be filled by agent
#         "inconsistency_check_result": None, # To be filled by agent
#         "provider_verification_check_result": None, # To be filled by agent
#         "service_reasonability_check_result": None, # To be filled by agent
#         "duplicate_claim_checked": False, # To be set by supervisor (or directly by agent if that's how it's designed)
#         "inconsistency_checked": False, # To be set by supervisor
#         "provider_verification_checked": False, # To be set by supervisor
#         "service_reasonability_checked": False, # To be set by supervisor
#         "final_amount": None,
#     }

#     # Convert row to dict for JSON serialization
#     row_dict = row.to_dict() if isinstance(row, pd.Series) else row
#     # log_trace(
#     #     policy_id,
#     #     "transform_row_to_claim_input",
#     #     {"row": row_dict, "input_data": input_data},
#     # )
#     return input_data


# workflow_map = {
#     "Auto_Insurance": create_graph_Auto_Insurance(),
# }

# if __name__ == "__main__":
#     df = pd.read_csv("notebooks/df_claims_with_notes.csv", encoding="ISO-8859-1")
#     print("Excel Data:", df.to_dict(orient="records"))  # Debug Excel input

#     for _, row in df.iterrows():
#         input_data = transform_row_to_claim_input(row)
#         domain = input_data.get("domain")

#         if domain not in workflow_map:
#             print(f"❌ Unsupported claim type: {domain}")
#             continue

#         print(
#             f"\n🚀 Running workflow for claim {input_data['policy_id']} ({domain})..."
#         )
#         workflow = workflow_map[domain]
#         result = workflow.invoke(input_data, config={"recursion_limit": 50})
#         result.pop("next_step_node", None)
#         print("✅ Final Result:", result)
