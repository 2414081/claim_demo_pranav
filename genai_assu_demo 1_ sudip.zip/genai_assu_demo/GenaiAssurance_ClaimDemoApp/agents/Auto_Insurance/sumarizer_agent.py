from langchain_core.runnables import Runnable
from langchain_core.messages import HumanMessage
from langchain_openai import AzureChatOpenAI
import os
from supervisor.supervisor_agent import *

# from metrics.tracker import log_trace
from configuration.logger import log_trace


load_dotenv()


from langchain.schema import HumanMessage
import json
from configuration.llm_manager import LLMManager
from configuration.state import GraphState
from configuration.logger import log_trace
from typing import Dict, Any
from langchain_core.runnables import Runnable
from langchain_core.runnables import RunnableLambda

#
# def get_summarizer_agent(llm):
#     def run(state):
#         policy_id = state.get("policy_id", "UNKNOWN")
#         claim_details = state.get("document_text", "")
#         doc_status = state.get("doc_status", "")
#         eligibility_status = state.get("eligibility_status", "")
#         fraud_status = state.get("fraud_status", "")
#         fraud_score = state.get("fraud_score", "")
#         estimated_cost = state.get("estimated_damage_cost", "")
#
#         prompt = f"""
#         You are an AI assistant summarizing a vehicle insurance claim.
#
#         Here are the claim details:
#         - Claim Text: {claim_details}
#         - Document Status: {doc_status}
#         - Eligibility Status: {eligibility_status}
#         - Fraud Check Status: {fraud_status}
#         - Fraud Score: {fraud_score}
#         - Estimated Damage Cost: {estimated_cost}
#
#         Based on this, generate:
#         - A short summary suitable for internal review.
#         - A confidence score (between 0 and 1) reflecting how complete and accurate the information is.
#
#         Respond in the following JSON format:
#         {{
#             "summary": "<summary text>",
#             "confidence": <float>
#         }}
#         """
#
#         messages = [HumanMessage(content=prompt)]
#         response = llm.invoke(messages)
#
#         try:
#             parsed = json.loads(response.content)
#         except json.JSONDecodeError:
#             parsed = {
#                 "summary": "Unable to parse summarizer response.",
#                 "confidence": 0.0,
#             }
#
#         # ✅ Log the output for traceability
#         log_trace(claim_id=policy_id, step="summarizer_agent", output=parsed)
#
#         return {
#             "summary": parsed.get("summary"),
#             "summary_confidence": parsed.get("confidence", 0.0),
#         }
#
#     return run


def get_summarizer_agent(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        policy_id = state.policy_id or "UNKNOWN"
        claim_details = state.document_text or "No document text provided"
        doc_status = (
        state.document_check_result.get("document_check_status")
        if state.document_check_result
        else None
    )
        eligibility_status = (
        state.eligibility_check_result.get("eligibility_status")
        if state.eligibility_check_result
        else None
    )
        fraud_status = state.fraud_status or "unknown"
        fraud_score = state.fraud_score or 0.0
        estimated_cost = state.estimated_damage_cost or "unknown"

        log_trace(
            policy_id,
            "summarizer_agent_input",
            {
                "state": state.dict(),
                "prompt_inputs": {
                    "claim_details": claim_details,
                    "doc_status": doc_status,
                    "eligibility_status": eligibility_status,
                    "fraud_status": fraud_status,
                    "fraud_score": fraud_score,
                    "estimated_cost": estimated_cost,
                },
            },
        )

        prompt = f"""
        You are an AI assistant summarizing a vehicle insurance claim.
        Here are the claim details:
        - Claim Text: {claim_details}
        - Document Status: {doc_status}
        - Eligibility Status: {eligibility_status}
        - Fraud Score: {fraud_score}
        - Estimated Damage Cost: {estimated_cost}
        Based on this, generate:
        - A short summary suitable for internal review.
        - A confidence score (between 0 and 1) reflecting how complete and accurate the information is.
        Respond in the following JSON format:
        {{
            "summary": "<summary text>",
            "confidence": <float>
        }}
        Ensure the response is valid JSON. If insufficient data is provided, generate a summary based on available information and assign a lower confidence score.
        """
        response = llm.invoke([HumanMessage(content=prompt)])
        response_content = (
            response.content.strip().replace("```json", "").replace("```", "")
        )
        print(
            "summary_response:", response.content
        )  # Debugging line to see the raw response
        try:
            parsed = json.loads(response_content)
            print(f"Parsed summary LLM response: {parsed}")  # Debugging line
            if (
                not isinstance(parsed, dict)
                or "summary" not in parsed
                or "confidence" not in parsed
            ):
                raise ValueError(
                    "Invalid LLM output: Expected a dictionary with 'summary' and 'confidence'"
                )
        except (json.JSONDecodeError, ValueError) as e:
            log_trace(
                policy_id,
                "summarizer_agent_error",
                {"error": str(e), "raw_response": response.content},
            )
            parsed = {
                "summary": f"Claim {policy_id}: {claim_details[:100]}... (truncated). Failed to generate full summary due to invalid LLM response.",
                "confidence": 0.5,
            }
        output = {
            "summary": parsed.get("summary", "No summary generated"),
            "confidence_score": float(parsed.get("confidence", 0.0)),
        }
        print(f"summary_agent: {output.get('summary')}")
        log_trace(claim_id=policy_id, step="summarizer_agent", output=output)
        return output

    return RunnableLambda(run)
