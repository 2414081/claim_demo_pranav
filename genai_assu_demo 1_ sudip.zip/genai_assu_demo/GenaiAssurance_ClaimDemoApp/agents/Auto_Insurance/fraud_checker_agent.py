from langchain_core.runnables import Runnable
from langchain_core.messages import HumanMessage
from langchain_openai import AzureChatOpenAI
import os
from dotenv import load_dotenv

from configuration.logger import log_trace
from supervisor.supervisor_agent import *
from supervisor import *
import json

load_dotenv()


# def get_fraud_checker_agent() -> Runnable:
#     def run(input):
#         claim = input.get("claim_details", "")
#         claim_id = input.get("claim_id", "")
#         documents = input.get("vehicle_documents", "")
#         est_cost = input.get("estimated_damage_cost", "")
#
#         prompt = f""" You are a vehicle insurance fraud detection expert.
#                       Analyze the claim details, submitted documents and estimated damage cost, and determining the likelihood of fraud:
#                       Claim: {claim}
#                       Documents: {documents}
#                       Estimated_cost: {est_cost}
#
#                       Classify the fraud risk as one of: LOW, MEDIUM,HIGH
#                       Also give a brief reason.
#
#                       Respond in the JSON format:
#                       {{"fraud_risk": "LOW",
#                         "reason": "Documents match claim and customer has clean history.",
#                         "confidence": 0.95   }}
#                         if some information is missing , make the best possible decision based on what is available. Do not ask for more data or clarification.
#                         """
#         response = llm.invoke([HumanMessage(content=prompt)])
#         result = response.content
#         try:
#             parsed_output = json.loads(result)
#         except json.JSONDecodeError:
#             parsed_output = {
#                 "fraud_risk": "MEDIUM",
#                 "reason": "Unable to parse LLM response to valid JSON. Possibly due to unclear or incomplete input.",
#                 "confidence": 0.0,
#             }
#         print(f"Inside fraud_checker_agent: claim_id = '{claim_id}'")
#         log_trace(claim_id, "fraud_checker", {"output": result})
#
#         return {**input, "fraud_check_result": parsed_output}
#
#     return run


import json
from datetime import datetime
from typing import Dict, Any
from langchain_core.runnables import Runnable
from langchain_core.messages import HumanMessage


# def get_fraud_checker_agent() -> Runnable:
#     damage_checker = fraud_damage_consistency_checker()
#     repair_checker = fraud_repair_estimate_checker()
#     duplicate_checker = fraud_duplicate_claim_checker()
#     veracity_checker = fraud_incident_veracity_checker()
#
#     def run(state: Dict[str, Any]) -> Dict[str, Any]:
#         claim_id = state.get("claim_id", f"CLM_{state.get('policy_id', '')}")
#
#         # Run all sub-agents
#         damage_result = damage_checker.invoke(state)
#         repair_result = repair_checker.invoke(damage_result["input"])
#         duplicate_result = duplicate_checker.invoke(repair_result["input"])
#         veracity_result = veracity_checker.invoke(duplicate_result["input"])
#
#         results = [
#             damage_result["damage_consistency_check_result"],
#             repair_result["repair_estimate_check_result"],
#             duplicate_result["duplicate_claim_check_result"],
#             veracity_result["incident_veracity_check_result"],
#         ]
#
#         overall_status = (
#             "passed" if all(r["status"] == "passed" for r in results) else "failed"
#         )
#         reasons = [r["reason"] for r in results]
#         avg_confidence = round(sum(r["confidence"] for r in results) / len(results), 2)
#
#         final_output = {
#             "timestamp": "2025-06-26T16:45:00",
#             "claim_id": claim_id,
#             "step": "fraud_checker_agent",
#             "status": overall_status,
#             "reason": "; ".join(reasons),
#             "confidence_score": avg_confidence,
#             "sub_results": results,
#         }
#
#         log_trace(
#             claim_id=state.get("policy_id", "UNKNOWN"),
#             step="fraud_checker_agent",
#             output=final_output,
#         )
#         return {"fraud_check_result": final_output, "input": veracity_result["input"]}
#
#     return run
#
#
# # Subagents Code:
#
#
# def fraud_damage_consistency_checker() -> Runnable:
#     def run(state: Dict[str, Any]) -> Dict[str, Any]:
#         claim_id = state.get("claim_id", f"CLM_{state.get('policy_id', '')}")
#         notes = state.get("notes", [])
#         policy_id = state.get("policy_id", "")
#         claim_type = state.get("claim_type", "")
#         police_report = state.get("police_report", "")
#         photos = state.get("photos", "")
#         claim_details = state.get("claim_details", "")
#
#         # Check for explicit note about damage_consistency
#         matching_note = next(
#             (
#                 note
#                 for note in notes
#                 if "fraud_checker_agent - damage_consistency" in note
#             ),
#             None,
#         )
#
#         if matching_note:
#             confidence = 0.9
#             status = "passed"
#             reason = matching_note
#         else:
#             # Build prompt for LLM to infer compliance
#             prompt = f"""
#             You are an insurance fraud detection assistant.
#
#             Task: Determine whether the claimed damages are consistent with the police report and photographic evidence.
#
#             Claim Details: {claim_details}
#             Police Report: {police_report}
#             Photographs: {photos}
#
#             Respond in the following JSON format:
#             {{
#               "status": "passed" or "failed",
#               "reason": "<short explanation>",
#               "confidence_score": <float between 0.4 and 0.8>
#             }}
#
#             If data is too sparse to decide definitively, assume partial compliance and assign confidence between 0.5–0.6.
#             Do not ask for more data.
#             """
#
#             response = llm.invoke([HumanMessage(content=prompt)])
#             try:
#                 parsed = json.loads(response.content)
#                 status = parsed.get("status", "failed")
#                 reason = parsed.get("reason", "Insufficient evidence.")
#                 confidence = float(parsed.get("confidence", 0.5))
#             except Exception:
#                 status = "failed"
#                 reason = "LLM response could not be parsed."
#                 confidence = 0.4
#
#         # Build final output
#         output = {
#             "timestamp": "2025-06-26T16:45:00",
#             "claim_id": claim_id,
#             "step": "fraud_checker_agent (Rule: damage_consistency)",
#             "status": status,
#             "reason": reason,
#             "confidence_score": confidence,
#         }
#
#         log_trace(
#             claim_id=state.get("policy_id", "UNKNOWN"),
#             step="fraud_checker_agent.damage_consistency",
#             output=output,
#         )
#
#         return {"damage_consistency_check_result": output, "input": state}
#
#     return run
#
#
# def fraud_repair_estimate_checker() -> Runnable:
#     def run(state: Dict[str, Any]) -> Dict[str, Any]:
#         claim_id = state.get("claim_id", f"CLM_{state.get('policy_id', '')}")
#         notes = state.get("notes", [])
#         claim_details = state.get("claim_details", "")
#         police_report = state.get("police_report", "")
#         photos = state.get("photos", "")
#         repair_estimate = state.get("repair_estimate", "")
#
#         matching_note = next(
#             (
#                 n
#                 for n in notes
#                 if "fraud_checker_agent - repair_estimate_inconsistencies" in n
#             ),
#             None,
#         )
#
#         if matching_note:
#             confidence = 0.9
#             status = "passed"
#             reason = matching_note
#         else:
#             prompt = f"""
#             You are a fraud analyst reviewing an insurance claim.
#
#             Determine whether the repair estimate contains inconsistencies not supported by the police report or photographic evidence.
#
#             Claim Details: {claim_details}
#             Police Report: {police_report}
#             Photos: {photos}
#             Repair Estimate: {repair_estimate}
#
#             Respond in JSON:
#             {{
#               "status": "passed" or "failed",
#               "reason": "<brief explanation>",
#               "confidence_score": <float between 0.4 and 0.8>
#             }}
#             """
#             try:
#                 response = llm.invoke([HumanMessage(content=prompt)])
#                 parsed = json.loads(response.content)
#                 status = parsed.get("status", "failed")
#                 reason = parsed.get("reason", "Unclear repair validation.")
#                 confidence = float(parsed.get("confidence", 0.5))
#             except Exception:
#                 status = "failed"
#                 reason = "LLM response could not be parsed."
#                 confidence = 0.4
#
#         output = {
#             "timestamp": "2025-06-26T16:45:00",
#             "claim_id": claim_id,
#             "step": "fraud_checker_agent (Rule: repair_estimate_inconsistencies)",
#             "status": status,
#             "reason": reason,
#             "confidence_score": confidence,
#         }
#
#         log_trace(
#             claim_id=state.get("policy_id", "UNKNOWN"),
#             step="repair_estimate_inconsistencies",
#             output=output,
#         )
#         return {"repair_estimate_check_result": output, "input": state}
#
#     return run
#
#
# def fraud_duplicate_claim_checker() -> Runnable:
#     def run(state: Dict[str, Any]) -> Dict[str, Any]:
#         claim_id = state.get("claim_id", f"CLM_{state.get('policy_id', '')}")
#         notes = state.get("notes", [])
#         claim_history = state.get("previous_claims", [])
#         claim_details = state.get("claim_details", "")
#
#         matching_note = next(
#             (
#                 n
#                 for n in notes
#                 if "fraud_checker_agent - duplicate_claim_prevention" in n
#             ),
#             None,
#         )
#
#         if matching_note:
#             confidence = 0.9
#             status = "passed"
#             reason = matching_note
#         else:
#             prompt = f"""
#             You are an insurance fraud reviewer.
#
#             Check whether this claim may be a duplicate of previous claims.
#
#             Claim Details: {claim_details}
#             Previous Claims: {claim_history}
#
#             Respond in JSON:
#             {{
#               "status": "passed" or "failed",
#               "reason": "<brief explanation>",
#               "confidence_score": <float between 0.4 and 0.8>
#             }}
#             """
#             try:
#                 response = llm.invoke([HumanMessage(content=prompt)])
#                 parsed = json.loads(response.content)
#                 status = parsed.get("status", "failed")
#                 reason = parsed.get("reason", "Possible duplication not confirmed.")
#                 confidence = float(parsed.get("confidence", 0.5))
#             except Exception:
#                 status = "failed"
#                 reason = "LLM response could not be parsed."
#                 confidence = 0.4
#
#         output = {
#             "timestamp": "2025-06-26T16:45:00",
#             "claim_id": claim_id,
#             "step": "fraud_checker_agent (Rule: duplicate_claim_prevention)",
#             "status": status,
#             "reason": reason,
#             "confidence_score": confidence,
#         }
#
#         log_trace(
#             claim_id=state.get("policy_id", "UNKNOWN"),
#             step="duplicate_claim_prevention",
#             output=output,
#         )
#         return {"duplicate_claim_check_result": output, "input": state}
#
#     return run
#
#
# def fraud_incident_veracity_checker() -> Runnable:
#     def run(state: Dict[str, Any]) -> Dict[str, Any]:
#         claim_id = state.get("claim_id", f"CLM_{state.get('policy_id', '')}")
#         notes = state.get("notes", [])
#         claim_details = state.get("claim_details", "")
#
#         matching_note = next(
#             (n for n in notes if "fraud_checker_agent - incident_veracity" in n), None
#         )
#
#         if matching_note:
#             confidence = 0.9
#             status = "passed"
#             reason = matching_note
#         else:
#             prompt = f"""
#             You are a fraud detection assistant.
#
#             Determine whether the reported incident might be fabricated or exaggerated.
#
#             Claim Details: {claim_details}
#
#             Respond in JSON:
#             {{
#               "status": "passed" or "failed",
#               "reason": "<brief explanation>",
#               "confidence_score": <float between 0.4 and 0.8>
#             }}
#             """
#             try:
#                 response = llm.invoke([HumanMessage(content=prompt)])
#                 parsed = json.loads(response.content)
#                 status = parsed.get("status", "failed")
#                 reason = parsed.get(
#                     "reason", "Possible fabrication cannot be ruled out."
#                 )
#                 confidence = float(parsed.get("confidence", 0.5))
#             except Exception:
#                 status = "failed"
#                 reason = "LLM response could not be parsed."
#                 confidence = 0.4
#
#         output = {
#             "timestamp": "2025-06-26T16:45:00",
#             "claim_id": claim_id,
#             "step": "fraud_checker_agent (Rule: incident_veracity)",
#             "status": status,
#             "reason": reason,
#             "confidence_score": confidence,
#         }
#
#         log_trace(
#             claim_id=state.get("policy_id", "UNKNOWN"),
#             step="incident_veracity",
#             output=output,
#         )
#         return {"incident_veracity_check_result": output, "input": state}
#
#     return run


import json
from datetime import datetime
from typing import Dict, Any
from langchain_core.runnables import Runnable, RunnableLambda
from langchain_core.messages import HumanMessage
from langchain_openai import (
    AzureChatOpenAI,
)  # Assuming this is used for LLM in sub-agents
import os
from dotenv import load_dotenv

from configuration.logger import log_trace
from configuration.state import GraphState  # Import GraphState

load_dotenv()


# We'll pass the LLM instance to each sub-agent
def fraud_damage_consistency_checker(llm: AzureChatOpenAI) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        state_data = state.dict()
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get(
            "notes", []
        )  # Access notes from claim_record
        document_text = state_data.get("document_text", "")
        # Assuming police_report and photos might be part of document_text or other state fields
        # For simplicity, let's use document_text for now
        police_report = document_text  # Placeholder
        photos = document_text  # Placeholder
        claim_details = state_data.get("claim_record", {}).get(
            "notes", "No specific claim details provided."
        )  # Using notes as a proxy for claim details

        # Check for explicit note about damage_consistency
        matching_note = next(
            (
                note
                for note in notes
                if "fraud_checker_agent - damage_consistency" in note
            ),
            None,
        )

        fraud_score = 0.0
        human_review = False
        status = "passed"
        reason = "No inconsistencies found."

        if matching_note:
            reason = matching_note
            # For demonstration, if a specific note exists, we assume no fraud from LLM here
            # In a real scenario, the note might indicate fraud. Adjust as needed.
        else:
            # Build prompt for LLM to infer consistency
            prompt = f"""
            You are an insurance fraud detection assistant.
            Task: Analyze the claimed damages, police report, and photographic evidence.
            Determine if the claimed damages are consistent with the supporting documents.

            Claim Details: {claim_details}
            Police Report Summary (from document): {police_report}
            Photographs Description (from document): {photos}
            Full Document Text: {document_text}

            Based on the provided information, assess the consistency and assign a fraud score from 0 to 100.
            - If damages are perfectly consistent: Score 0.
            - If there are minor inconsistencies (e.g., slight discrepancies, vague details): Score between 30 and 70.
            - If there are major inconsistencies (e.g., clear contradictions, severe misrepresentation): Score above 70.

            Respond in the following JSON format:
            {{
              "status": "consistent" or "inconsistent",
              "reason": "<short explanation for the consistency/inconsistency>",
              "fraud_score": <integer score between 0 and 100>
            }}

            If data is too sparse to decide definitively, assume minor inconsistency and assign a score between 30-40.
            Do not ask for more data.
            """

            response = llm.invoke([HumanMessage(content=prompt)])
            try:
                parsed = json.loads(response.content)
                status_llm = parsed.get("status", "inconsistent")
                reason = parsed.get("reason", "Insufficient evidence.")
                fraud_score = float(
                    parsed.get("fraud_score", 35.0)
                )  # Default if parsing fails or score missing

                if status_llm == "consistent":
                    fraud_score = 0.0  # Force 0 if LLM explicitly says consistent
                elif fraud_score > 70:
                    status = "failed"
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                else:  # 0 < fraud_score <= 30
                    status = "passed_with_minor_flags"  # Or whatever internal status you prefer for low score
                    human_review = False

            except Exception as e:
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0  # High fraud score if parsing fails
                human_review = False  # No automated human review, needs manual investigation of error

        output = {
            "timestamp": datetime.now().isoformat(),
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: damage_consistency)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,  # Return the score
            "human_review_required": human_review,  # Return human review flag
        }

        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="fraud_checker_agent.damage_consistency",
            output=output,
        )

        return {
            "damage_consistency_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

    return RunnableLambda(run)


def fraud_repair_estimate_checker(llm: AzureChatOpenAI) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        state_data = state.dict()
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get("notes", [])
        document_text = state_data.get("document_text", "")
        # Assuming repair_estimate, police_report, photos might be part of document_text or other state fields
        repair_estimate = state_data.get(
            "estimated_damage_cost", ""
        )  # Using the extracted estimated cost
        police_report = document_text  # Placeholder
        photos = document_text  # Placeholder
        claim_details = state_data.get("claim_record", {}).get(
            "notes", "No specific claim details provided."
        )

        matching_note = next(
            (
                n
                for n in notes
                if "fraud_checker_agent - repair_estimate_inconsistencies" in n
            ),
            None,
        )

        fraud_score = 0.0
        human_review = False
        status = "passed"
        reason = "Repair estimate is consistent."

        if matching_note:
            reason = matching_note
        else:
            prompt = f"""
            You are a fraud analyst reviewing an insurance claim.
            Determine whether the repair estimate contains inconsistencies when compared to the claim details, police report, and photographic evidence.

            Claim Details: {claim_details}
            Police Report Summary (from document): {police_report}
            Photos Description (from document): {photos}
            Repair Estimate (from document): {repair_estimate}
            Full Document Text: {document_text}

            Based on the provided information, assess the consistency and assign a fraud score from 0 to 100.
            - If estimate is perfectly consistent: Score 0.
            - If there are minor inconsistencies: Score between 30 and 70.
            - If there are major inconsistencies: Score above 70.

            Respond in JSON:
            {{
              "status": "consistent" or "inconsistent",
              "reason": "<brief explanation>",
              "fraud_score": <integer score between 0 and 100>
            }}
            If data is too sparse to decide definitively, assume minor inconsistency and assign a score between 30-40.
            """
            try:
                response = llm.invoke([HumanMessage(content=prompt)])
                parsed = json.loads(response.content)
                status_llm = parsed.get("status", "inconsistent")
                reason = parsed.get("reason", "Unclear repair validation.")
                fraud_score = float(parsed.get("fraud_score", 35.0))

                if status_llm == "consistent":
                    fraud_score = 0.0
                elif fraud_score > 70:
                    status = "failed"
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                else:
                    status = "passed_with_minor_flags"
                    human_review = False

            except Exception as e:
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0
                human_review = False

        output = {
            "timestamp": datetime.now().isoformat(),
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: repair_estimate_inconsistencies)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="repair_estimate_inconsistencies",
            output=output,
        )
        return {
            "repair_estimate_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

    return RunnableLambda(run)


def fraud_duplicate_claim_checker(llm: AzureChatOpenAI) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        state_data = state.dict()
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get("notes", [])
        # Assuming previous_claims can be derived or is part of state
        claim_history = (
            []
        )  # Placeholder: You might need to fetch this from a DB or add to GraphState
        claim_details = state_data.get("claim_record", {}).get(
            "notes", "No specific claim details provided."
        )
        document_text = state_data.get("document_text", "")

        matching_note = next(
            (
                n
                for n in notes
                if "fraud_checker_agent - duplicate_claim_prevention" in n
            ),
            None,
        )

        fraud_score = 0.0
        human_review = False
        status = "passed"
        reason = "No duplicate claim detected."

        if matching_note:
            reason = matching_note
        else:
            prompt = f"""
            You are an AI assistant specialized in detecting duplicate insurance claims.
            Task: Evaluate if the current claim is a duplicate of a previous claim based on available information.

            Current Claim Details: {claim_details}
            Current Claim Document: {document_text}
            Customer Claim History (if available): {claim_history}

            Assign a fraud score from 0 to 100 based on the likelihood of a duplicate claim:
            - If definitely not a duplicate: Score 0.
            - If suspicious but not confirmed (e.g., similar details but different dates/amounts): Score between 30 and 70.
            - If highly likely a duplicate: Score above 70.

            Respond in JSON:
            {{
              "status": "not_duplicate" or "duplicate" or "suspicious",
              "reason": "<brief explanation>",
              "fraud_score": <integer score between 0 and 100>
            }}
            If data is too sparse to decide definitively, assume suspicious and assign a score between 30-40.
            """
            try:
                response = llm.invoke([HumanMessage(content=prompt)])
                parsed = json.loads(response.content)
                status_llm = parsed.get("status", "suspicious")
                reason = parsed.get("reason", "Unclear duplicate claim status.")
                fraud_score = float(parsed.get("fraud_score", 35.0))

                if status_llm == "not_duplicate":
                    fraud_score = 0.0
                elif fraud_score > 70:
                    status = "failed"
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                else:
                    status = "passed_with_minor_flags"
                    human_review = False

            except Exception as e:
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0
                human_review = False

        output = {
            "timestamp": datetime.now().isoformat(),
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: duplicate_claim_prevention)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="duplicate_claim_prevention",
            output=output,
        )
        return {
            "duplicate_claim_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

    return RunnableLambda(run)


def fraud_incident_veracity_checker(llm: AzureChatOpenAI) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        state_data = state.dict()
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get("notes", [])
        claim_details = state_data.get("claim_record", {}).get(
            "notes", "No specific claim details provided."
        )
        document_text = state_data.get("document_text", "")
        accident_date = state_data.get("claim_record", {}).get("accident_date", "")

        matching_note = next(
            (n for n in notes if "fraud_checker_agent - incident_veracity" in n),
            None,
        )

        fraud_score = 0.0
        human_review = False
        status = "passed"
        reason = "Incident veracity confirmed."

        if matching_note:
            reason = matching_note
        else:
            prompt = f"""
            You are an AI assistant verifying the truthfulness of an insurance incident.
            Task: Assess the veracity of the claimed incident based on all available documents and details. Look for any inconsistencies or suspicious patterns.

            Claim Details: {claim_details}
            Document Text: {document_text}
            Accident Date: {accident_date}

            Assign a fraud score from 0 to 100 based on the veracity of the incident:
            - If incident is highly believable/verified: Score 0.
            - If there are minor inconsistencies or suspicious elements: Score between 30 and 70.
            - If the incident seems highly fabricated or contradictory: Score above 70.

            Respond in JSON:
            {{
              "status": "verified" or "suspicious" or "fabricated",
              "reason": "<brief explanation>",
              "fraud_score": <integer score between 0 and 100>
            }}
            If data is too sparse to decide definitively, assume suspicious and assign a score between 30-40.
            """
            try:
                response = llm.invoke([HumanMessage(content=prompt)])
                parsed = json.loads(response.content)
                status_llm = parsed.get("status", "suspicious")
                reason = parsed.get("reason", "Incident veracity unclear.")
                fraud_score = float(parsed.get("fraud_score", 35.0))

                if status_llm == "verified":
                    fraud_score = 0.0
                elif fraud_score > 70:
                    status = "failed"
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                else:
                    status = "passed_with_minor_flags"
                    human_review = False

            except Exception as e:
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0
                human_review = False

        output = {
            "timestamp": datetime.now().isoformat(),
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: incident_veracity)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="incident_veracity",
            output=output,
        )
        return {
            "incident_veracity_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

    return RunnableLambda(run)


# The orchestrating get_fraud_checker_agent is removed as per the request,
# as the individual sub-agents will be directly added to the workflow.
# However, for consistency, if you still want a function that returns all of them:
def get_fraud_checker_agents(llm: AzureChatOpenAI):
    return {
        "damage_consistency": fraud_damage_consistency_checker(llm),
        "repair_estimate": fraud_repair_estimate_checker(llm),
        "duplicate_claim": fraud_duplicate_claim_checker(llm),
        "incident_veracity": fraud_incident_veracity_checker(llm),
    }
