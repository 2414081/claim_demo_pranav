import json
from typing import Dict, Any
from datetime import datetime
from langchain_core.messages import HumanMessage
from langchain_core.runnables import Runnable
from langchain_core.runnables import RunnableLambda
from configuration.llm_manager import LLMManager
from configuration.logger import log_trace
from langchain.schema import HumanMessage

# from supervisor.supervisor_agent import *
from configuration.state import GraphState

# def vehicle_document_agent() -> Runnable:
#     def run_agent(input: dict):
#         claim_id = input.get("claim_id", "")
#         document_info = input.get("vehicle_documents", "")
#         claim_context = input.get("claim_details", "")
#
#         messages = [
#             HumanMessage(
#                 content=f""" You are an expert vehicle insurance document analyst.
#                                Here are the claim details: {claim_context}
#                                Attached are the submitted documents:
#                                {document_info}
#                                Analyze the documents and determine if they are:
#                                -VALID: All documents are present and seem genuine.
#                                -INCOMPLETE: Some key documents are missing.
#                                -FAKE: Documents seem forged or manipulated.
#                                -SUSPICIOUS: Something seems off and unclear
#                     Respond strictly in JSON format like this:
#                     {{
#                       "status": <Status of the docs>,
#                       "reason": <A Brief Reason for your evaluation>,
#                       "confidence": <Calculated Confidence score>
#                     }}
#
#                     If the information is missing or unclear, do your best to conclude based on what's available. Do not ask follow-up questions."""
#             )
#         ]
#         response = llm.invoke(messages)
#         result = response.content
#         log_trace(claim_id, "document_verifier_agent", {"output": result})
#         return {**input, "document_check_result": result}
#
#     return run_agent
llm = LLMManager().get_llm()


def document_verifier_agent(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        state_data = state.dict()  # type: ignore
        claim_record = state_data.get("claim_record", {})
        rules = state_data.get("rules", [])
        policy_id = claim_record.get("policy_id", state.policy_id)
        claim_id = f"CLM_{policy_id}"
        is_valid_claim = state_data.get("is_valid_claim", False)
        print(is_valid_claim)
        reason = state_data.get("reason", "")

        log_trace(
            claim_id,
            "document_verifier_agent_input",
            {
                "state": state_data,
                "is_valid_claim": is_valid_claim,
                "rules": rules,
                "reason": reason,
            },
        )

        # Validate claim_record completeness
        required_fields = [
            "name",
            "policy_id",
            "policy_start",
            "policy_end",
            "claim_type",
            "accident_date",
            "claim_amount",
        ]
        missing_fields = [
            field for field in required_fields if not claim_record.get(field)
        ]
        if missing_fields or not claim_record:
            parsed = [
                {
                    "timestamp": datetime.utcnow().isoformat(),
                    "claim_id": claim_id,
                    "step": "document_verifier_agent",
                    "doc_status": "failed",
                    "reason": f"Incomplete claim record: missing {', '.join(missing_fields) if missing_fields else 'claim_record'}",
                    "confidence_score": 0.0,
                }
            ]
            log_trace(claim_id, "document_verifier_agent", {"output": parsed[0]})
            return {"document_verification_result": parsed, "input": state_data}

        # Use is_valid_claim and rules if available
        if is_valid_claim:
            parsed = [
                {
                    "timestamp": datetime.utcnow().isoformat(),
                    "claim_id": claim_id,
                    "step": "document_verifier_agent",
                    "doc_status": "passed",
                    "reason": reason or "Claim validated based on input data",
                    "confidence_score": 0.9,
                }
            ]
            log_trace(claim_id, "document_verifier_agent", {"output": parsed[0]})
            return {"document_verification_result": parsed, "input": state_data}
            # Validate claim_record completeness only if is_valid_claim is False
            required_fields = [
                "name",
                "policy_id",
                "policy_start",
                "policy_end",
                "claim_type",
                "accident_date",
                "claim_amount",
            ]
            missing_fields = [
                field for field in required_fields if not claim_record.get(field)
            ]
            if missing_fields or not claim_record:
                parsed = [
                    {
                        "timestamp": datetime.utcnow().isoformat(),
                        "claim_id": claim_id,
                        "step": "document_verifier_agent",
                        "doc_status": "failed",
                        "reason": f"Incomplete claim record: missing {', '.join(missing_fields) if missing_fields else 'claim_record'}",
                        "confidence_score": 0.0,
                    }
                ]
                log_trace(claim_id, "document_verifier_agent", {"output": parsed[0]})
                return {"document_verification_result": parsed, "input": state_data}

        prompt = f"""
                You are an AI assistant tasked with validating an insurance claim for the document_verification_agent based on provided claim details and predefined rules.
                You will receive:
                1. A claim record with fields: `name`, `policy_id`, `policy_start`, `policy_end`, `claim_type`, `accident_date`, `claim_amount`, and `notes` (a list of strings indicating rule validations or inferences).
                2. A set of rules specific to the document_verification_agent for the claim type 'Auto Insurance (Collision Coverage or Theft)'.
                Your task is to:
                - Validate the claim record against the provided rules for the document_verification_agent.
                - Check the `notes` for explicit rule validations (e.g., "document_verification_agent - rule_name: description").
                - For rules not explicitly mentioned in `notes`, infer compliance based on the claim fields (e.g., check `accident_date` against `policy_start` and `policy_end` for `incident_date_verification`).
                - If any rule fails, the agent's status is "failed". All rules must pass for the status to be "passed".
                - Assign a confidence score (between 0.0 and 1.0) based on the strength of the evidence or inference:
                  - Use 0.9 for rules explicitly validated in notes or rules.
                  - Use 0.6–0.8 for inferred validations based on fields.
                  - Use 0.4–0.5 for rules requiring external data with no explicit note.
                Output STRICTLY a JSON result with a single entry for the document_verifier_agent, including:
                - `timestamp`: Current UTC timestamp
                - `claim_id`: Constructed as `CLM_{{policy_id}}`
                - `step`: The agent name, "document_verifier_agent"
                - `status`: Either "passed" or "failed"
                - `reason`: A concise explanation of the validation result
                - `confidence_score`: A float between 0.0 and 1.0 reflecting confidence in the result
                **Input Data:**
                Claim Record:
                {json.dumps(claim_record, indent=2)}
                Rules for document_verification_agent (Claim Type 'Auto Insurance (Collision Coverage or Theft)'):
                {json.dumps(rules, indent=2)}
                Output format:
                [
                  {{
                    "timestamp": "<current UTC timestamp>",
                    "claim_id": "CLM_{policy_id}",
                    "step": "document_verifier_agent",
                    "doc_status": "<passed/failed>",
                    "reason": "<explanation>",
                    "confidence_score": <float>
                  }}
                ]
                Ensure the response is valid JSON.
                """
        response = llm.invoke([HumanMessage(content=prompt)])
        # tool_response =
        try:
            # parsed = json.loads(response.content)
            response_content = (
                response.content.strip().replace("```json", "").replace("```", "")
            )
            parsed = json.loads(response_content)
            if (
                not isinstance(parsed, list)
                or not parsed
                or not isinstance(parsed[0], dict)
            ):
                raise ValueError(
                    "Invalid LLM output: Expected a list with a dictionary"
                )
        except (json.JSONDecodeError, ValueError) as e:
            log_trace(
                claim_id,
                "document_verifier_agent_error",
                {"error": str(e), "raw_response": response.content, "prompt": prompt},
            )
            parsed = [
                {
                    "timestamp": datetime.utcnow().isoformat(),
                    "claim_id": claim_id,
                    "step": "document_verifier_agent",
                    "doc_status": "failed",
                    "reason": f"Unable to parse LLM output: {str(e)}",
                    "confidence_score": 0.0,
                    # "tool_response":
                }
            ]
        parsed[0]["raw_llm_response"] = response.content
        log_trace(claim_id=claim_id, step="document_verifier_agent", output=parsed[0])
        print("Document Verification Result:", parsed)
        return {"document_verification_result": parsed, "input": state_data}

    return RunnableLambda(run)
