from langgraph.graph import END
from typing import Dict, Any
from configuration.state import GraphState
from configuration.logger import log_trace


def supervisor_agent_medical(state: GraphState) -> Dict[str, Any]:
    log_trace(
        state.policy_id, "supervisor_agent_medical_input", {"state": state.dict()}
    )

    # Core states
    doc_status = state.doc_status
    eligibility_status = state.eligibility_status
    fraud_score = state.fraud_score  # Overall fraud score
    human_review_required = state.human_review_required  # Overall human review flag
    summary = bool(state.summary)
    decision = bool(state.decision)

    # Individual fraud check statuses for health insurance
    # These would be set to True by the respective fraud sub-agents
    duplicate_claim_checked = state.duplicate_claim_checked
    inconsistency_checked = state.inconsistency_checked
    provider_verification_checked = state.provider_verification_checked
    service_reasonability_checked = state.service_reasonability_checked

    print(
        f"\n--- SupervisorAgent (Medical) ---\nState: doc_status={doc_status}, "
        f"eligibility_status={eligibility_status}, fraud_score={fraud_score}, "
        f"human_review_required={human_review_required}, summary={summary}, "
        f"decision={decision}"
        f"\nHealth Fraud Checks: Duplicate={duplicate_claim_checked}, Inconsistency={inconsistency_checked}, "
        f"Provider={provider_verification_checked}, Service Reasonability={service_reasonability_checked}"
    )

    # Step 1: Handle initial document rejection
    if doc_status == "rejected" and not summary:
        print("❌ Document rejected. Routing to SummaryAgent.")
        return {"next_step_node": "SummaryAgent"}
    elif doc_status == "rejected" and summary and not decision:
        print("❌ Document rejected, summary available. Routing to DecisionMaker.")
        return {"next_step_node": "DecisionMaker"}

    # Step 2: Document approved, proceed to EligibilityChecker if not done
    elif doc_status == "approved" and eligibility_status is None:
        print("✅ Document approved. Routing to EligibilityChecker.")
        return {"next_step_node": "EligibilityChecker"}

    elif eligibility_status == "rejected":
        if not summary:
            print("❌ Eligibility rejected. Routing to SummaryAgent.")
            return {"next_step_node": "SummaryAgent"}
        elif summary and not decision:  # Assuming decision_present is a state variable
            print(
                "❌ Eligibility rejected, summary available. Routing to DecisionMaker."
            )
            return {"next_step_node": "DecisionMaker"}

    # Step 3: Eligibility approved, now start/continue fraud checks
    elif eligibility_status == "approved":
        # Check if any fraud score is present (greater than 0)
        # This mirrors the logic from the auto insurance supervisor directly.
        if fraud_score is not None and fraud_score > 0 and not summary:
            print(f"⚠️ Fraud score {fraud_score} detected. Routing to SummaryAgent.")
            return {"next_step_node": "SummaryAgent"}
        elif fraud_score is not None and fraud_score > 0 and summary and not decision:
            print(
                f"⚠️ Fraud score {fraud_score} detected, summary available. Routing to DecisionMaker."
            )
            return {"next_step_node": "DecisionMaker"}

        # If no significant fraud score yet (or score is 0),
        # proceed through individual fraud sub-agents.
        # The order here defines the sequence of fraud checks.
        if not duplicate_claim_checked:
            print("➡️ Routing to FraudDuplicateClaimChecker.")
            return {
                "next_step_node": "FraudDuplicateClaimChecker",
                "duplicate_claim_checked": True,
            }
        elif not inconsistency_checked:
            print("➡️ Routing to FraudInconsistencyChecker.")
            return {
                "next_step_node": "FraudInconsistencyChecker",
                "inconsistency_checked": True,
            }
        elif not provider_verification_checked:
            print("➡️ Routing to FraudProviderVerificationChecker.")
            return {
                "next_step_node": "FraudProviderVerificationChecker",
                "provider_verification_checked": True,
            }
        elif not service_reasonability_checked:
            print("➡️ Routing to FraudServiceReasonabilityChecker.")
            return {
                "next_step_node": "FraudServiceReasonabilityChecker",
                "service_reasonability_checked": True,
            }

        # Step 4: All fraud checks completed without triggering a fraud score > 0,
        # and no summary yet.
        elif not summary:
            print(
                "✅ All fraud checks completed without significant fraud. Routing to SummaryAgent."
            )
            return {"next_step_node": "SummaryAgent"}

        # Step 5: All checks completed, summary available, and no decision yet.
        elif summary and not decision:
            print("✅ Summary available. Proceeding to DecisionMaker.")
            return {"next_step_node": "DecisionMaker"}

    # Fallback/Completion: If none of the above conditions are met, the workflow ends.
    print("✅ All steps completed or invalid state. Workflow ending.")
    return {"next_step_node": END}
