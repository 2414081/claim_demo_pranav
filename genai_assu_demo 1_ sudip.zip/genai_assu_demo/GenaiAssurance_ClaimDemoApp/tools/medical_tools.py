from langchain.tools import tool
import requests


# Tool 1: Verify Provider NPI
@tool
def verify_provider_npi(provider_id: str) -> str:
    """
    Verifies a healthcare provider using the NPI Registry API.
    """
    try:
        response = requests.get(
            f"https://npiregistry.cms.hhs.gov/pi/?number={provided_id}"
        )
        data = response.json()
        if data.get("results"):
            return f"Provided with NPI {provider_id} is verified."
        else:
            return "No match found."
    except Exception as e:
        return f"Error verifying provider: {str(e)}"


# Tool 2: Lookup Prior Medical Claims

# @tool
# def lookup_prior_claims(policy_id: str, procedure: str) -> str:
#      """
#     Simulates checking a claim database for duplicate or overlapping claims.
#     Returns a string describing if duplicates exist.
#     """
#     # Mock logic
#     if hash(policy_id + procedure) %3 == 0:
#         return "duplicate claim found for similar procedure"
#     return "No prior similar claims"


# Tool 3: Check Medical Coverage Rules
@tool
def check_coverage_rules(policy_id: str, procedure_Code: str) -> str:
    """
    Simulates checking policy coverage for a specific medical procedure.
    """
    covered_codes = ["PROC-001", "PROC-002", "PROC-005"]
    if procedure_code in covered_codes:
        return f"Procedure {procedure_code} is covered under the policy {policy_id}"
    return f"Procedure {procedure_code} is NOT covered under the policy {policy_id}"


# Tool 4: Benchmark Medical Cost Estimate
@tool
def benchmark_medical_cost(procedure_code: str, claim_amount: float) -> str:
    """
    Compares claimed cost to standard benchmark for the given procedure.
    Returns overcharge or undercharge info.
    """
    benchmark_table = {
        "PROC-001": 10000,
        "PROC-002": 12000,
        "PROC-003": 8000,
        "PROC-005": 11000,
    }
    benchmark = benchmark_table.get(procedure_code, 10000)
    if claim_amount > benchmark * 1.1:
        return f"Claimed amount {claim_amount} exceeds benchmark ({benchmark}) by more than 10%"
    elif claim_amount < benchmark * 0.9:
        return f"Claimed amount{claim_amount} is significantly below benchmark ({benchmark})"
    return f"Claimed amount {claim_amount} is withing acceptable range of benchmark ({benchmark})"
