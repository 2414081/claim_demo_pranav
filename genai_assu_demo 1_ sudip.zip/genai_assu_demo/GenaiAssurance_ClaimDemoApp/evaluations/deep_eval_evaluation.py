import importlib, json

from datasets import Dataset
import pandas as pd
from pydantic import BaseModel

from deepeval import evaluate
from deepeval.test_case import (
    LLMTestCase,
    ToolCall,
    ConversationalTestCase,
    LLMTestCaseParams,
)


def log_deepeval_evaluations(single_input, custom_az_llm):

    df_results = pd.DataFrame([single_input])
    test_case = LLMTestCase(**single_input)

    # conversational_case = ConversationalTestCase(
    #     chatbot_role="assistant", turns=[test_case]
    # )

    module = importlib.import_module("deepeval.metrics")

    evaluations = [
        # {"name of metric": "Faithfulness", "input parameters": {}},
        {
            "name of metric": "ToxicityMetric",
            "input parameters": {"threshold": 0.7},
        },
    ]

    for index, evaluation in enumerate(evaluations):

        class_name = evaluation["name of metric"].strip()
        # params = evaluation["input parameters"].replace("_x000D_", "")
        # params = params.replace("_x000d_", "")
        # params = json.loads(params)
        params = evaluation["input parameters"]

        print(f"Running deep eval evaluation for {class_name}")
        cls = getattr(module, class_name)
        if class_name == "ConversationalGEval":
            params.update(
                {
                    "evaluation_params": [
                        LLMTestCaseParams.INPUT,
                        LLMTestCaseParams.ACTUAL_OUTPUT,
                    ]
                }
            )
        elif class_name == "GEval":
            params.update(
                {
                    "evaluation_params": [
                        LLMTestCaseParams.INPUT,
                        LLMTestCaseParams.ACTUAL_OUTPUT,
                        LLMTestCaseParams.EXPECTED_OUTPUT,
                    ]
                }
            )
        elif class_name == "JsonCorrectnessMetric":

            expected_schema = create_schema_for_json_correctness(
                "ExampleSchema", params["custom_fields"]
            )
            del params["custom_fields"]
            params.update({"expected_schema": expected_schema})

        if class_name in ["ToolCorrectnessMetric"]:
            metric = cls(**params)
        else:
            metric = cls(model=custom_az_llm, **params)

        score = evaluate(test_cases=[test_case], metrics=[metric])
        actual_score = score.test_results[0].metrics_data[0].score
        reason = score.test_results[0].metrics_data[0].reason
        df_results[f"deep_eval_score_{class_name}"] = actual_score
        df_results[f"deep_eval_reason_{class_name}"] = reason


def create_schema_for_json_correctness(class_name: str, fields: dict):

    annotations = {key: field for key, field in fields.items()}
    new_fields = {"__annotations__": annotations, "__module__": __name__}
    new_fields.update({key: None for key in fields})

    return type(class_name, (BaseModel,), new_fields)
